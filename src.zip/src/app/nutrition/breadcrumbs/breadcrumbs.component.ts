import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { Title } from '@angular/platform-browser';
@Component({
  selector: 'app-breadcrumbs',
  templateUrl: './breadcrumbs.component.html',
  styleUrls: ['./breadcrumbs.component.scss']
})

export class BreadcrumbsComponent {
  
  steps=[
    {step:'services', transition: 1},
    {step:'location', transition: 1},
    {step:'schedule', transition: 1},
    {step:'review', transition: 1},
  ]
  route:any='';
  
  constructor(private titleService: Title, private router: ActivatedRoute, private _location: Location) {
    this.titleService.setTitle('Nutrition - Silver Mirror');
    this.route=this.router.url;
    router.url.subscribe((url=>{
      const path = url.length ? url[0].path : '';
      const index = this.steps.findIndex((step) => step.step.includes(path));
      index > -1 ? this.steps[index].transition = 3 : null;
      for (let i = index-1; i >= 0; i--){
        this.steps[i].transition = 2;
      }
    }));
  }

  getRouteState(transition:number){
    switch (transition) {
      case 1:
        return ''
      case 2:
        return 'completed'
      case 3:
        return 'active'
      default:
        return ''
    }
  }

  navigateBack(){
    this._location.back();
  }

}
