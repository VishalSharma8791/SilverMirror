import { Pipe, PipeTransform } from '@angular/core';
import { SharedService } from 'src/app/shared-component/shared.service';

@Pipe({
  name: 'NutritionServiceOrder'
})
export class NutritionServiceOrderPipe implements PipeTransform {

  constructor(private sharedService:SharedService){}

  transform(services: Array<any>): Array<any> {
    return services.sort((a,b)=> Number(this.sharedService.getServiceOrder(a.description)) - Number(this.sharedService.getServiceOrder(b.description)));
  }
  
}
