export const GIFTCARD_NAMES = {
    "115":'30-Minute Facial',
    "155":'50-Minute Facial',
    "500":'Mother\'s Day Gift Card - $100 Off',
    "custom":'Gift Card'
}