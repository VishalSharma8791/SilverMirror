import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { LocationComponent } from "./booking/location/location.component";

@NgModule({
  imports: [
    RouterModule.forRoot([
      { path: "", redirectTo: "/booking/location", pathMatch:'full' }
    ],{ useHash: false }),
  ],
  exports: [RouterModule],
})
export class AppRoutingModule {}
