import { Component } from '@angular/core';
import { GiftcardService, giftCardsPresets } from '../giftcards.service';
import { SharedService } from 'src/app/shared-component/shared.service';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from 'src/app/auth/auth.service';
import { GIFTCARD_NAMES } from 'src/app/constants/constants';
import { TrackingService } from 'src/app/giftcards/tracking.service';

@Component({
  selector: 'app-giftcard-detail',
  templateUrl: './giftcard-detail.component.html',
  styleUrls: ['./giftcard-detail.component.scss']
})
export class GiftcardDetailComponent {

  giftCards:any;
  isCustomAmountSelected:boolean = true;
  customAmount:any;
  confirmAmountValidation:boolean = false;
  enableStep2:boolean = false;
  today:any;
  user:any;
  paramPreset:any;

  recipientType:string = "someone";
  recipientForm!:FormGroup;

  constructor(private route: ActivatedRoute, private authService:AuthService, private trackingService:TrackingService, public giftCardService:GiftcardService, public sharedService:SharedService, private formBuilder:FormBuilder, private router:Router){
    giftCardService.createCart();
    this.giftCardService.selectedGiftCard.subscribe((card:any)=>{
      if(card?.price && card?.price >= (giftCardService.getGiftCardMinMaxPrice().min / 100) && card?.price <= giftCardService.getGiftCardMinMaxPrice().max / 100){
        this.confirmAmountValidation = true;
      }else{
        this.confirmAmountValidation = false;
      }
    });
    giftCardService.clientCart$.subscribe((cart:any)=>{
      if(cart){
        this.giftCards = cart.availableCategories[cart.availableCategories.length - 1]?.availableItems[0].pricePresets.map((price:any, index:number)=> {return {min: giftCardService.getGiftCardMinMaxPrice().min, max: giftCardService.getGiftCardMinMaxPrice().max, price: price / 100, description: giftCardsPresets[index].description, title: giftCardsPresets[index].title}});

        if(this.paramPreset){
          const gift = {price: this.paramPreset};
          this.selectGiftCard(gift);
        }
        
        if(cart.selectedItems.length){
          const recipientType = localStorage.getItem('recipientType');
          recipientType ? this.recipientType = recipientType : null;
          const giftcard:any = this.giftCards.find((card:any)=>{
            return card.price == cart?.selectedItems[0]?.price/100
          });
          if(!giftcard?.price){
            this.isCustomAmountSelected = true;
            this.confirmAmountValidation = true;
            this.customAmount =  cart?.selectedItems[0]?.price/100;
            this.giftCardService.selectedGiftCard.next({price: this.customAmount});
          }else{
            this.selectGiftCard(giftcard);
          }
        }
      }
    })
  }

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this.paramPreset = params['preset'];
    });
    this.getToday();
    this._buildForm();
    this.authService.$AuthUser.subscribe((user:any)=>{
      if(user){
        this.user = user;
        this._patchAdditionalInfoForm(user);
      }
    });
  }

  getToday(dateValue?:string){
    let date = dateValue ? new Date(dateValue) : new Date();
    let m = Number(new Date().getMonth()) + 1;
    let y = new Date().getFullYear();
    let d = new Date().getDate();
    let returnDate = (m < 10 ? '0'+m : m)  + '/' + (d < 10 ? '0'+d : d) + '/' + y;
    !dateValue ? this.today = returnDate : null;
    return returnDate;
  }

  sendDateValidator(control: FormControl): { [key: string]: any } | null {
    if(control.value){
      let date = new Date();
      let m = Number(new Date().getMonth()) + 1;
      let y = new Date().getFullYear();
      let d = new Date().getDate();
      let returnDate = (m < 10 ? '0'+m : m)  + '/' + (d < 10 ? '0'+d : d) + '/' + y;
      const today = returnDate;

      let controlDate =  control.value.substr(5,2) + '/' + control.value.substr(8,2) + '/' + control.value.substr(0,4);

      const valid = new Date(controlDate).setHours(0,0,0,0) >= new Date(today).setHours(0,0,0,0);

      return valid ? null : { invalidSendDate: true };
    }else{
      return { invalidSendDate: true };
    }
  }

  _patchAdditionalInfoForm(user:any){
    this.recipientForm.patchValue({
      // senderName:user.firstName + ' ' + user.lastName,
      // senderEmail: user.email,
      sendDate: this.today
    });
    // this.recipientForm.controls.senderEmail.disable();
    // this.recipientForm.controls.senderName.disable();
  }

  _patchRecipientForm(recipient:any){
    if(recipient){
      this.recipientForm.patchValue({
        recipientName: recipient.recipientName,
        // senderName: recipient.senderName,
        recipientEmail: recipient.recipientEmail,
        // senderEmail: this?.user?.email,
        message: recipient.messageFromSender,
        sendDate: new Date() > new Date(recipient.deliveryDate) ? this.today : this.getToday(recipient.deliveryDate),
      });
    }
  }

  _buildForm(){
    // PaymentForm
    this.recipientForm = this.formBuilder.group({
      recipientName: ['', Validators.required],
      // senderName: ['', Validators.required],
      recipientEmail: ['', Validators.compose([Validators.required, Validators.email])],
      // senderEmail: ['', Validators.compose([Validators.email])],
      message: [''],
      sendDate: [this.today, Validators.compose([Validators.required, this.sendDateValidator])],
    });
  }

  selectGiftCard(giftCard:any){
    this.isCustomAmountSelected = false;
    this.giftCards.map((card:any)=> card.selected = false);
    giftCard.selected = true;
    this.giftCardService.selectedGiftCard.next(giftCard);
    this.customAmount = null;
  }

  selectCustomAmount(){
    this.isCustomAmountSelected = true;
    this.giftCards.map((card:any)=> card.selected = false);
    this.giftCardService.selectedGiftCard.next({price: this.customAmount});
  }

  changeCustomAmount(ev:any){
    setTimeout(() => {
      this.giftCardService.selectedGiftCard.next({price: this.customAmount});
    });
  }

  confirmAmountValidator(){
    if(!this.confirmAmountValidation && this.isCustomAmountSelected){
      const title = 'Please enter an amount.';
      const message = '';
      this.sharedService.showNotification(title, message);
      return false;
    }else if(!this.confirmAmountValidation && !this.isCustomAmountSelected){
      const title = 'Please select an amount.';
      const message = '';
      this.sharedService.showNotification(title, message);
      return false;
    }else{
      return true;
    }
  }

  confirmAmount(){
    if(this.confirmAmountValidator()){
      this.giftCardService.isCustomAmountSelected = this.isCustomAmountSelected;
      const cart = this.giftCardService.clientCart$.value;
      if(cart && cart?.selectedItems?.length){
        const trackItem = {
          name: this.sharedService.getLocalStorageItem('giftCardName'),
          id:"GIFT_CARD",
          listPrice:cart.selectedItems[0].price,
          total:cart.summary.total
        }
        this.trackingService.removeItem(trackItem);
        this.giftCardService.updateGiftCard().subscribe((res:any)=>{
          if(!res.errors){
            this.enableStep2 = true;
            this.giftCardService.getCartDetail();
            const trackItem = {
              name: this.sharedService.getLocalStorageItem('giftCardName'),
              id:"GIFT_CARD",
              listPrice:this.giftCardService.selectedGiftCard.value.price * 100,
              total:this.giftCardService.selectedGiftCard.value.total * 100
            }
            this.trackingService.addItem(trackItem);
            const title = 'Gift card amount';
            const message = 'added successfully';
            this.sharedService.showNotification(title, message);
          }else{
            this.sharedService.showNotification("Error", res.errors[0].message);
          }
        });
      }else{
        this.giftCardService.addGiftCard().subscribe((res:any)=>{
          if(!res.errors){
            this.enableStep2 = true;
            this.giftCardService.getCartDetail();
            const trackItem = {
              name: this.sharedService.getLocalStorageItem('giftCardName'),
              id:"GIFT_CARD",
              listPrice:this.giftCardService.selectedGiftCard.value.price * 100,
              total:this.giftCardService.selectedGiftCard.value.total * 100
            }
            this.trackingService.addItem(trackItem);
            const title = 'Gift card amount';
            const message = 'added successfully';
            this.sharedService.showNotification(title, message);
          }else{
            this.sharedService.showNotification("Error", res.errors[0].message);
          }
        });
      }
      this._patchRecipientForm(cart?.selectedItems[0]?.emailFulfillment);
    }

    this.setGiftCardName();
  }

  setGiftCardName(){
    if(this.isCustomAmountSelected){
      this.sharedService.setLocalStorageItem('giftCardName', GIFTCARD_NAMES.custom);
    }else if(this.giftCardService.selectedGiftCard.value.price == 119){
      this.sharedService.setLocalStorageItem('giftCardName', GIFTCARD_NAMES[115]);
    }else if(this.giftCardService.selectedGiftCard.value.price == 159){
      this.sharedService.setLocalStorageItem('giftCardName', GIFTCARD_NAMES[155]);
    }else if(this.giftCardService.selectedGiftCard.value.price == 500){
      this.sharedService.setLocalStorageItem('giftCardName', GIFTCARD_NAMES[500]);
    }
  }

  activeStep(step:number){
    this.enableStep2 = step == 1 ? false : true;
  }

  changeRecipient(ev:any){
    if(ev == 'myself'){
      const user = this.authService.$AuthUser.value;
      if(user){
        this.recipientForm.patchValue({
          recipientName: user.firstName + ' ' + user.lastName,
          // senderName: user.firstName + ' ' + user.lastName,
          recipientEmail: user.email,
          // senderEmail: user.email,
          sendDate: this.today
        });
      }
    }else if(ev == 'someone'){
      const user = this.authService.$AuthUser.value;
      if(user){
        this.recipientForm.reset();
        this._patchAdditionalInfoForm(user);
      }
    }else{
      this.recipientForm.reset();
    }
    localStorage.setItem('recipientType', ev);
  }

  setGiftCardDesign(){
    const design = {
      id: "177c95c9-c310-463e-8b08-b662535cfc53"
    }
    this.giftCardService.setCardDesign(design).subscribe();
  }

  continue(){
    this.setGiftCardDesign();
    const cart = this.giftCardService.clientCart$.value;
    if(cart && cart?.selectedItems?.length){
      let payload = this.recipientForm.value;
      // payload.senderEmail = this.recipientForm.controls['senderEmail'].value;
      // payload.senderName = this.recipientForm.controls['senderName'].value;
      payload.senderName = "Me";
      this.giftCardService.updateEmailfulfilment(payload).subscribe((res:any)=>{
        if(!res.errors){
          this.giftCardService.getCartDetail();
          const title = 'Recipient information';
          const message = 'added successfully';
          this.sharedService.showNotification(title, message);
          this.router.navigateByUrl("/giftcards/review");
          // this.router.navigateByUrl("/giftcards/email-design");
        }else{
          this.sharedService.showNotification("Error", res.errors[0].message);
        }
      });
    }else{
      this.giftCardService.setEmailfulfilment(this.recipientForm.value).subscribe((res:any)=>{
        if(!res.errors){
          this.giftCardService.getCartDetail();
          this.router.navigateByUrl("/giftcards/review");
          // this.router.navigateByUrl("/giftcards/email-design");
          const title = 'Recipient information';
          const message = 'added successfully';
          this.sharedService.showNotification(title, message);
        }else{
          this.sharedService.showNotification("Error", res.errors[0].message);
        }
      });
    }
    
  }

}
