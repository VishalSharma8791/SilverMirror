import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GiftcardDetailComponent } from './giftcard-detail.component';

describe('GiftcardDetailComponent', () => {
  let component: GiftcardDetailComponent;
  let fixture: ComponentFixture<GiftcardDetailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GiftcardDetailComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GiftcardDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
