import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmailDesignComponent } from './email-design.component';

describe('EmailDesignComponent', () => {
  let component: EmailDesignComponent;
  let fixture: ComponentFixture<EmailDesignComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EmailDesignComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EmailDesignComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
