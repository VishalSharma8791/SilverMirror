import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { GiftcardService } from '../giftcards.service';
import { SharedService } from 'src/app/shared-component/shared.service';

@Component({
  selector: 'app-email-design',
  templateUrl: './email-design.component.html',
  styleUrls: ['./email-design.component.scss']
})
export class EmailDesignComponent {

  giftCardDesigns:any;
  selectedDesign:any;

  constructor(private router:Router, public giftCardService:GiftcardService, private sharedService:SharedService){
    giftCardService.getGiftCardDesigns();
    giftCardService.clientCart$.subscribe((cart:any)=>{
      if(cart && cart?.selectedItems[0]?.giftCardDesign){
        this.selectedDesign = cart?.selectedItems[0]?.giftCardDesign;
      }
    });
    giftCardService.giftCardDesigns.subscribe((designs:any)=>{
      if(designs){
        this.giftCardDesigns = designs;
        if(!giftCardService.clientCart$.value){
          giftCardService.getCartDetail();
        }
      }
    })
  }

  selectDesign(design:any){
    this.selectedDesign = design.design;
  }

  continue(){
    if(this.selectedDesign){
      this.giftCardService.setCardDesign(this.selectedDesign).subscribe((res:any)=>{
        if(!res.errors){
          this.giftCardService.getCartDetail();
          const title = 'Gift card design';
          const message = 'added successfully';
          this.sharedService.showNotification(title, message);
          this.router.navigateByUrl("/giftcards/review");
        }else{
          this.sharedService.showNotification("Error", res.errors[0].message);
        }
      });
    }else{
      const title = 'Design not selected';
      const message = 'Please select the design';
      this.sharedService.showNotification(title, message);
    }
  }

}
