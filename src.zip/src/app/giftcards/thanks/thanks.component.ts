import { Component } from '@angular/core';
import { GiftcardService } from '../giftcards.service';
import { SharedService } from 'src/app/shared-component/shared.service';
import { TrackingService } from '../tracking.service';
import { jsPDF } from "jspdf";
import { Router } from '@angular/router';
import { PDF_INTERFACE, PdfService } from '../pdf.service';

@Component({
  selector: 'app-thanks',
  templateUrl: './thanks.component.html',
  styleUrls: ['./thanks.component.scss']
})
export class ThanksComponent {

  cart:any;
  taxDetail:any;
  giftcardCode:any = '';
  
  constructor(public sharedService:SharedService, private trackingService:TrackingService, public giftcardService:GiftcardService, public router:Router, private pdfService:PdfService){
    if(!this.cart){
      giftcardService.clientCart$.subscribe((cart:any)=>{
        this.cart = cart;
        if(this.cart){
          const giftId = this.cart?.selectedItems[0]?.id
          this.injectGTAG(giftId);
          this.getGiftcardCode();
        }else{
          router.navigateByUrl('/giftcards', {replaceUrl: true});
        }
      })
    }
    if(giftcardService.taxdetail.isTaxable){
      this.taxDetail = giftcardService.taxdetail;
    }
  }

  injectGTAG(giftId:string){
    this.trackingService.setUserDetail();
    this.trackingService.purchase();

    (window as any).gtag('event', 'conversion', {
      'send_to': 'AW-1056511307/uq4qCNDxjpECEMuq5PcD',
      'value': Number(this.sharedService.formatPrice(this.cart?.summary?.total)),
      'currency': 'USD',
      'transaction_id': giftId
      });
  }

  clearCart(){
    this.giftcardService.clientCart$.next(null);
    this.giftcardService.selectedGiftCard.next(null);
    this.giftcardService.giftCardDesigns.next(null);
    setTimeout(() => {
      localStorage.removeItem('giftCardName');
    }, 1000);
  }

  // getGiftCardName(){
  //   let price;
  //   if(this.taxDetail.isTaxable){
  //     price = this.taxDetail.subTotal
  //   }else{
  //     price = this.cart?.selectedItems[0]?.lineTotal
  //   }
  //   switch (price) {
  //     case 115:
  //       return '30-Minute Facial'
  //       break;
  //     case 155:
  //       return '50-Minute Facial'
  //       break;
  //     default:
  //       return 'Gift Card'
  //       break;
  //   }
  // }

  ngOnDestroy(){
    this.clearCart();
    this.taxDetail = null;
    this.giftcardService.taxdetail = {
      tax: 0,
      total: 0,
      subTotal: 0,
      discount: 0,
      isTaxable: false
    }
  }

  getGiftcardCode(){
    this.giftcardService.getGiftcardCode(this.cart.id).subscribe((res:any)=>{
      console.log("cart detail :: ", res);
      this.giftcardCode = res?.data?.cart?.orders[0]?.lineGroups[0]?.lines[0]?.giftCardCode;
      const payload = {
        sender:this.cart?.selectedItems[0].emailFulfillment?.senderName,
        receiver:this.cart?.selectedItems[0].emailFulfillment?.recipientName,
        amount:this.taxDetail?.isTaxable && !this.giftcardService.isCustomAmountSelected ? (this.taxDetail.subTotal) : (this.sharedService.formatPrice(this.cart?.selectedItems[0]?.lineTotal)),
        code:this.giftcardCode,
        message:this.cart?.selectedItems[0].emailFulfillment?.messageFromSender ? this.cart?.selectedItems[0].emailFulfillment?.messageFromSender : '',
        senderEmail:this.cart?.clientInformation?.email,
        receiverEmail:this.cart?.selectedItems[0].emailFulfillment?.recipientEmail,
      }
    })
  }

  // downloadPDF(){
  //   const template = `
  //   <div id="makepdf">
  // <style>
  //     body{
  //       margin:0;
  //       padding:0;
  //       border: 0;
  //       outline: 0;
  //       font-size: 100%;
  //       vertical-align: baseline;
  //       background: transparent;
  //     }
  //     #table_menu{
  //       table-layout: fixed;
  //       width: 100%;
  //     }
  //     .menu-link{
  //       color: #fff !important;
  //       font-style: Normal;
  //       font-weight: 600;
  //       text-decoration: none;
  //       display: inline-block;
  //       background: transparent;
  //       font-family: 'Averta', Arial, Helvetica, sans-serif;
  //       font-size: 12px;
  //       line-height: 100%;
  //       letter-spacing: 0;
  //       margin: 0;
  //       text-transform: none;
  //       padding: 6px 10px 6px 10px;
  //       mso-padding-alt: 0;
  //       border-radius: 18px;
  //     }
  //     .main-banner{
  //       text-align:center; 
  //       margin:30px 0 20px 0; 
  //       width:100%; 
  //       height:auto; 
  //     }
  
  //     .main-banner img.logo-icon{
  //       width: 70px; 
  //     }
  
  //     .main-banner span{
  //       width: 100%; 
  //       display:block; 
  //       padding-top: 10px;
  //     }
  
  //     .title-font{
  //       font-size:36px;
  //       font-family: 'Freight Display Pro', 'freight-display-pro', Georgia, serif;
  //       font-weight:600;
  //       margin:10px 0 0px 0;
  //       text-align:center; 
  //       color:#000;
  //       line-height: 40px;
  //       padding: 0px;
  //     }
  //     .sub-title-font{
  //       font-size:24px;
  //       font-family:'Averta',Arial,Helvetica,sans-serif;
  //       letter-spacing: 0px;
  //       margin: 10px 0 0 0;
  //     }
      
  //     .recommended-facial-img{
  //       margin:0px 0; 
  //       max-width:450px;
  //       width:100%;
  //       height:auto;
  //       border-radius:50px;
  //     }
  //     .start-bg{
  //       background-image: url('https://d3k81ch9hvuctc.cloudfront.net/company/UVZkc7/images/48f6fd29-b9f9-4e52-8823-f6fb258bfc98.png');
  //       background-size: 80%;
  //       background-repeat: no-repeat;
  //       background-position: center;
  //       padding: 10px 0;
  //       margin-top: 0;
  //     }
  //     .start-bg-blue{
  //       background-image: url('https://d3k81ch9hvuctc.cloudfront.net/company/UVZkc7/images/af0f1718-4922-4343-8b35-59f17ab9f877.png');
  //       background-size: 95%;
  //       background-repeat: no-repeat;
  //       background-position: center;
  //       padding: 20px 0 20px 0;
  //       margin-top: 0;
  //       margin-bottom: 0px !important;
  //     }
  //     .share-glow{
  //       font-size:20px;
  //       font-family: 'Averta',Arial,Helvetica,sans-serif;
  //       font-weight:600;
  //       letter-spacing: 1.0px;
  //       width:320px;
  //       padding:15px 10px;
  //       box-sizing: border-box;
  //       margin:0px auto;
  //       display:grid;
  //       justify-content: center;
  //       align-items: center;
  //       text-align:center;
  //       line-height: 30px;
  //       background:#ffe276;
  //       -webkit-border-bottom-left-radius: 20px;
  //       -webkit-border-top-right-radius: 20px;
  //       -moz-border-radius-bottomleft: 20px;
  //       -moz-border-radius-topright: 20px;
  //       border-bottom-left-radius: 20px;
  //       border-top-right-radius: 20px;
  //     }
  //     .share-glow.blue{
  //       background:#d6ebff;
  //       font-size:16px;
  //     }
  //     .share-glow span{
  //       display: block;
  //       letter-spacing: 2.5px;
  //     }
  //     img.button-link{
  //       width: 100%;
  //       max-width: 200px;
  //     }
  //     .border-dashed{
  //       float:left;
  //       width:100%;
  //       margin:10px 0 50px 0;
  //       border-bottom:2px dashed #000;
  //     }
  //     .description-main{
  //        font-size:20px; 
  //        margin:0px 0 30px 0;
  //        text-align:center; 
  //        float:left; 
  //        width:100%; 
  //        line-height: 2rem;
  //        padding: 0 30px;
  //        box-sizing: border-box;
  //     }
  //     .description-main span{
  //        font-weight:600;
  //     }
  //     .description-title{
  //       text-align:center; 
  //       float:left; 
  //       width:100%;
  //       margin:0px 0 10px 0;
  //     }
  //     .description-title span{
  //         font-size:16px;  
  //        line-height: 1.6rem;
  //        letter-spacing: 2.5px;
  //        background:#d6ebff;
  //        border-radius:20px;
  //        padding:3px 30px 0px;
  //        display: inline-block;
  //     }
  //     .description-title.yellow span{
  //        background:#ffe276;
  //     }
  //     .social-icon{
  //        list-style:none; 
  //        padding:0; 
  //        margin:40px 0 30px 0; 
  //        display:block; 
  //        text-align:center; 
  //     }
  //     .social-icon li{
  //        display:inline-block;
  //        padding:0 5px;
  //     }
  //     .btn.primary, .btn.secondary {
  //       letter-spacing: 1.5px;
  //       padding: 19px 30px;
  //       text-align: center;
  //       z-index: 2;
  //       color: #000;
  //       border: 2px solid #50aaf2;
  //       background:#fff;
  //       -webkit-box-shadow: 5px 5px 0px 0px rgba(80,170,242,1);
  //     -moz-box-shadow: 5px 5px 0px 0px rgba(80,170,242,1);
  //     box-shadow: 5px 5px 0px 0px rgba(80,170,242,1);
  //     }
  //     .btn {
  //       display: inline-block;
  //       font-family:'Averta',Arial,Helvetica,sans-serif;
  //       font-size: 16px;
  //       line-height: 1.3rem;
  //       font-weight: 600;
  //       position: relative;
  //       text-transform: uppercase;
  //       color: #000;
  //       text-decoration: none;
  //       transition: all .25s ease;
  //     }
  //     .btn.secondary{
  //       background: #000;
  //       color:#fff;
  //       transform: translate(5px,5px);
  //       transition: transform .25s ease;
  //       width: 100%;
  //       box-sizing: border-box;
  //       font-weight:500;
  //       padding: 15px 30px;
  //       border: none;
  //           box-shadow: none;
  //     }
  //     .mobile-view{
  //       display:none;
  //     }
  //     .im {
  //       color: #000 !important;
  //     }
  //     .yellow-box{
  //       float:left;
  //       margin: 15px 0;
  //       width: 100%;
  //       padding:50px 20px;
  //       box-sizing: border-box;
  //       background:#ffe276;
  //       font-size:20px; 
  //       font-family: 'Averta', Arial, Helvetica, sans-serif; 
  //       line-height: 2.0rem;
  //       color:#000;
  //       height: auto;
  //       -webkit-border-top-right-radius: 100px;
  //       -webkit-border-bottom-left-radius: 100px;
  //       -moz-border-radius-topright: 100px;
  //       -moz-border-radius-bottomleft: 100px;
  //       border-top-right-radius: 100px;
  //       border-bottom-left-radius: 100px;
  //     }
  //     .yellow-box .title-font{
  //       float:left;
  //       width: 100%;
  //       font-size:28px;
  //       font-family: 'Freight Display Pro', 'freight-display-pro', Georgia, serif;
  //       font-weight:600;
  //       margin:0px 0 40px 0;
  //       text-align:center; 
  //       color:#000;
  //       line-height: 40px;
  //       padding: 0px;
  //     }
  //     .yellow-box p span{
  //       font-weight:600;
  //     }
  //     .main-form {
  //       text-align: left;
  //       margin: 30px 0 0px 0;
  //       width: 100%;
  //       float:left;
  //       height: auto;
  //     }
  //     .row {
  //       display: flex;
  //       gap:30px;
  //       margin-bottom:20px;
  //     }
  //     .row .column {
  //       flex: 50%;
  //     }
  //     .form-input{
  //       background: #D6EBFF;
  //       padding: 12px 20px;
  //       display: block;
  //       border-radius: 20px;
  //       font-size: 18px;
  //       color: #000;
  //     }
  //     .form-input span{
  //       font-weight:600;
  //     }
  //     .footer{
  //       float:left;
  //       width:100%;
  //       font-size:16px; 
  //       font-family: 'Averta', Arial, Helvetica, sans-serif; 
  //       line-height: 2.0rem;
  //       color:#000;
  //       text-align:left;
  //     }
  
  //     .footer-left{
  //       float:left;
  //       width:65%;
        
  //     }
  //     .footer-left p{
  //       white-space:nowrap;
  //     }
  //     .footer-left p span{
  //       font-weight:600;
  //     }
  //     .footer-right{
  //       float:left;
  //       width:35%;
  //       font-size:12px; 
  //       text-align:right;
  //       white-space:nowrap;
  //     }
  //     .footer-right p img{
  //       width:65px;
  //     }
  //     @media screen and (max-device-width:640px){
  //       .mobile-view{
  //         display:block;
  //       }
  //       .desktop-view{
  //         display:none;
  //       }
  //       .main-banner{
  //         height:auto; 
  //         margin: 15px 0;
  //       }
  //       .main-banner span{
  //         padding-top: 20px;
  //       }
  //       .title-font{
  //         font-size:24px;
  //         line-height: 24px;
  //         margin-bottom: 0px;
  //         margin-top: 0;
  //       }
  //       .header-facial-title {
  //         font-size: 16px;
  //         margin-top: 0px;
  //         letter-spacing: 0.5;
  //         }
  //       .sub-title-font {
  //         font-size: 18px;
  //       }
  //       .share-glow{
  //         font-size:18px;
  //       }
  //       .description-main {
  //         width: 100%;
  //         font-size: 18px;
  //         padding: 0 0;
  //        }
  //       .btn.primary, .btn.secondary {
  //         letter-spacing: 1.0px;
  //         padding: 10px 20px;
  //       }
  //       .yellow-box .title-font{
  //         float:left;
  //         width: 100%;
  //         font-size:24px;
  //       }
  //       .yellow-box{
  //         font-size:16px; 
  //       }
  //       .row {
  //         display: grid;
  //         gap: 20px;
  //         margin-bottom: 20px;
  //       }
  //       .row .column {
  //         flex: 100%;
  //       }
  //       .recommended-facial-img {
  //         margin: 0px 0;
  //         max-width: 300px;
  //         width: 100%;
  //         height: auto;
  //         border-radius: 30px;
  //       }
  //       .footer-left, .footer-right{
  //         float:left;
  //         width:100%;
  //         text-align: center;
  //       }
  //       .footer-left p{
  //         white-space:normal;
  //       }
  //       .footer {
  //         text-align: center;
  //       }
  //     }
  
  //     @media print {
  //       @page {
  //         size: A3;
  //       }
  //       body {
  //         transform: scale(1);
  //       }
  //       table {page-break-inside: avoid;}
  //       .form-input{
  //         background: #D6EBFF !important;
  //         print-color-adjust: exact; 
  //       }
  //       .noPrint{
  //         display:none;
  //       }
  //     }
  //   </style>
  //     <table bgcolor="#fff" border="0" cellpadding="0" cellspacing="0" style="border-collapse:collapse!important" valign="top" width="70%">      
  //       <tbody>        
  //         <tr>          
  //           <td align="center" valign="top">            
  //             <div style="border-radius:0px; max-width:1024px;width:100%;margin:20px 0 20px 0;">              
  //               <table bgcolor="#fff" border="0" cellpadding="0" cellspacing="0" style="width: 100%; color:#000; font-size:12px; font-family: 'Averta', Arial, Helvetica, sans-serif; line-height: 1.6rem; border-collapse:collapse!important;border-radius:0px;" valign="top" width="100%">                
  //                 <tbody>                  
  //                   <tr>                    
  //                     <td align="center" valign="top" width="50"></td>
  //                     <td align="center" height="100" valign="middle">                      
  //                       <p style="text-align:center; margin:30px 0 0 0;">                        <a href="https://silvermirror.com/" target="_blank">
  //                           <img alt="Silver Mirror" id="logo" src="../assets/svgs/booking-logo.png" style="margin-left: 0px; width:260px;"/></a>
  //                       </p>
  //                     </td>
  //                     <td align="center" valign="top" width="50"></td>
  //                   </tr>
  //                   <tr>                    
  //                     <td align="center" valign="top" width="50"></td>
  //                     <td align="left" valign="top"> 
              
  //                       <div class="main-banner">
  //             <span>
  //                           <p class="title-font">Facial Gift Cards</p>
  //             </span>
  //                       </div>
  
  //             <div class="main-form">
  
  //               <div class="row">
  //               <div class="column">
  //                 <div class="form-input">
  //                   SENDER NAME: ${this.cart?.selectedItems[0].emailFulfillment?.senderName}
  //                 </div>
  //               </div>
  //               <div class="column">
  //                 <div class="form-input">
  //                   RECEIVER NAME: ${this.cart?.selectedItems[0].emailFulfillment?.recipientName}
  //                 </div>
  //               </div>
  //             </div>
  //             <div class="row">
  //               <div class="column">
  //                 <div class="form-input">
  //                   GIFT CARD AMOUNT: <span>$${this.taxDetail?.isTaxable && !this.giftcardService.isCustomAmountSelected ? (this.taxDetail.subTotal) : (this.sharedService.formatPrice(this.cart?.selectedItems[0]?.lineTotal))}</span>
  //                 </div>
  //               </div>
  //               <div class="column">
  //                 <div class="form-input">
  //                   GIFT CARD CODE: <span>${this.giftcardCode}</span>
  //                 </div>
  //               </div>
  //             </div>
  //             <div class="row">
  //               <div class="column">
  //                 <div class="form-input" style="min-height:100px;">
  //                   MESSAGE: ${this.cart?.selectedItems[0].emailFulfillment?.messageFromSender ? this.cart?.selectedItems[0].emailFulfillment?.messageFromSender : ''}
  //                 </div>
  //               </div>
  //             </div>
  
  //             </div>
  
  //             <p class="border-dashed">&nbsp;</p>
  
  //             <p class="description-main" style="margin-bottom:10px;">  
  //               <span class="sub-title-font">About Silver Mirror</span>
  //             </p>
  
  //             <p class="description-main">Silver Mirror, the original facial bar founded in 2016, has been changing the skincare game since its inception. By fusing state-of-the-art medspa technology with the mastery of world-class estheticians, our customized facial treatments are not only designed to fit your busy schedule but also adapt to your skin's unique needs, all while creating an experience of unrivaled luxury.</p>
  
  //             <p style="text-align:center; margin-bottom:30px; float:left; width:100%;">                        
  //                         <img alt="Silver Mirror" class="recommended-facial-img" src="../assets/images/gift-card-email-banner.jpg"/>
  //                       </p>
              
  //                     </td>
  //                     <td align="center" valign="top" width="50"></td>
  //                   </tr>
  //                 </tbody>
  //               </table>
  
  
  //       <!-- Footer -->
  //               <table bgcolor="#fff" border="0" cellpadding="0" cellspacing="0" style="color:#000; font-size:12px; font-family: 'Averta', Arial, Helvetica, sans-serif; line-height: 1.6rem; border-collapse:collapse!important;border-radius:0px; width: 100%;" valign="top" width="">                
  //                 <tbody>                  
  //                   <tr>                    
  //                     <td align="center" valign="top" width="18"></td>
  //                     <td align="center" valign="middle">
  
  //             <div class="footer">
  //               <div class="footer-left">
  //                 <p>
  //                   <span>SILVER MIRROR LOCATIONS</span></br>
  //                   <b>New York:</b> Upper East Side &#x2022; Flatiron &#x2022; Bryant Park &#x2022; Manhattan West</br>
  //                   <b>Washington, DC:</b> Dupont Circle &#x2022; Navy Yard &#x2022; Penn Quarter</br>
  //                   <b>Miami:</b> Brickell &#x2022; Coral Gables
  //                 </p>
  //               </div>
  //               <div class="footer-right">
  //                 <p>
  //                   MORE INFO</br>
  //                   <img alt="Silver Mirror" src="../assets/images/gift-card-scan-code.jpg" /></br>
  //                   888 6770055&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;SILVERMIRROR.COM
  //                 </p>
  //               </div>
  //             </div>
  //                     </td>
  //                     <td align="center" valign="top" width="18"></td>
  //                   </tr>
  //                 </tbody>
  //               </table>
  //             </div>
  //           </td>
  //         </tr>
  //       </tbody>
  //     </table>
  //   </div>`

  //   let mywindow:any = window.open("", "PRINT", "width=100, height=100");

  //   mywindow.document.write(template);

  //   mywindow.document.close();
  //   // mywindow.focus();

  //   const node:any = mywindow.document.querySelector('#makepdf');
  //   let pdf = new jsPDF('p', 'mm', [1100, 1400]);

  //   setTimeout(() => {
  //     pdf.html(node, {x:0, y:0}).then(doc=>{
  //       pdf.save('giftcard.pdf'); // Generated PDF
  //       pdf.close();
  //       mywindow.close();
  //       const title = 'Giftcard PDF downloaded';
  //       const message = 'Please check your download folder.';
  //       this.sharedService.showNotification(title, message);
  //     });
  //   }, 500);
  // }

  downloadPDF(){
    // const testParam:PDF_INTERFACE = {
    //   sender: 'Himanshu Sharma',
    //   receiver: 'Suresh B.',
    //   amount:'155',
    //   code:'X8G7JH0',
    //   message: 'Silver Mirror, the original facial bar founded in 2016, has been changing the skincare game since its inception. By fusing state-of-the-art medspa technology with the mastery of world-class estheticians, our customized facial treatments are not only designed to fit your busy schedule but also adapt to your skin\'s unique needs, all while creating an experience of unrivaled luxury.'
    // }

    // this.pdfService.createPDF(testParam);

    const param:PDF_INTERFACE = {
      sender:this.cart?.selectedItems[0].emailFulfillment?.senderName,
      receiver:this.cart?.selectedItems[0].emailFulfillment?.recipientName,
      amount:this.taxDetail?.isTaxable && !this.giftcardService.isCustomAmountSelected ? (this.taxDetail.subTotal) : (this.sharedService.formatPrice(this.cart?.selectedItems[0]?.lineTotal)),
      code:this.giftcardCode,
      message:this.cart?.selectedItems[0].emailFulfillment?.messageFromSender ? this.cart?.selectedItems[0].emailFulfillment?.messageFromSender : ''
    }

    this.pdfService.createPDF(param);
    const title = 'Silvermirror Giftcard PDF downloaded';
    const message = 'Please check your download folder.';
    this.sharedService.showNotification(title, message);
  }

}