import { Injectable } from "@angular/core";
import { AuthService } from "../auth/auth.service";
import { BookingService } from "../booking/booking.service";
import { HttpClient } from "@angular/common/http";
import { SharedService } from "../shared-component/shared.service";
import { BehaviorSubject, map } from "rxjs";
import { environment } from "src/environments";
import { GIFTCARD_NAMES } from "../constants/constants";

const BASE_URL = environment.apiBaseURL;
const LOCATION_ID = environment.giftcard_location_id;
const PAYMENT_API_BASE_URL = environment.paymentApiBaseURL;

export const giftCardsPresets = [
  {
    description: 'We know you\'re busy. So we\'ve engineered an entire menu of options that will have you in, out, and on-the-glow in half a lunch hour.',
    title: GIFTCARD_NAMES[115]
  },
  {
    description: 'Stay a little while longer. Every 50-Minute facial is completely customized to your skin type and tone — pick the one that best suits your skin goals, and let our estheticians personalize the facial for your needs.',
    title: GIFTCARD_NAMES[155]
  },
  {
    description: 'Purchase a $500 Gift Card and receive $100 off. Offer ends May 12, 2024 at 11:59 PM EST.',
    title: GIFTCARD_NAMES[500]
  },
  {
    description: 'Stay a little while longer. Every 50-Minute facial is completely customized to your skin type and tone — pick the one that best suits your skin goals, and let our estheticians personalize the facial for your needs.',
    title: GIFTCARD_NAMES[115]
  }
]
@Injectable({
  providedIn: "root",
})
export class GiftcardService {
  authUser: any;
  clientCart$:BehaviorSubject<any> = new BehaviorSubject(null);
  selectedGiftCard:BehaviorSubject<any> = new BehaviorSubject(null);
  giftCardDesigns:BehaviorSubject<any> = new BehaviorSubject(null);
  isCustomAmountSelected = false;

  taxdetail = {
    isTaxable: false,
    tax: 0,
    total: 0,
    subTotal: 0,
    discount: 0
  }

  constructor(private http:HttpClient, private sharedService:SharedService, private bookingService:BookingService, private authService: AuthService) {
    authService.$AuthUser.subscribe((user) => {
      this.authUser = user;
    });
  }

  // create cart
  createCart(){
    const cartId = localStorage.getItem('giftCart');
    if(!cartId){
      this.bookingService.createCart(LOCATION_ID).subscribe((res:any)=>{
        if(!res.errors){
          localStorage.setItem('giftCart', res.data.createCart.cart.id);
          this.getCartDetail();
        }else{
          this.sharedService.showNotification("Error", res.errors[0].message);
        }
      });
    }else{
      if(!this.clientCart$.value){
        this.getCartDetail();
      }
    }
  }

// TODO: Listing gift cards
getAvailableGiftCards(){
  return this.clientCart$.value.data.cart.availableCategories[this.clientCart$.value.data.cart.availableCategories.length];
}

// TODO: Add giftcard in cart with item price
addGiftCard(){
  const payload = {
    clientId: this.authService.$AuthUser.value?.authId,
    cartId:localStorage.getItem('giftCart'),
    itemId:"GIFT_CARD",
    itemPrice:this.selectedGiftCard.value.price * 100
  }; 
  return this.http.post(BASE_URL+'/add_giftcard_in_cart',payload);
}

updateGiftCard(){
  const payload = {
    clientId: this.authService.$AuthUser.value?.authId,
    cartId:localStorage.getItem('giftCart'),
    itemId: this.clientCart$.value.selectedItems[0].id,
    itemPrice: this.sharedService.decimalRound(this.selectedGiftCard.value.price * 100)
  }; 
  return this.http.post(BASE_URL+'/update_giftcard_in_cart',payload);
}

// TODO: sender & RECIPIENT detail update in cart (emailfulfilment)
setEmailfulfilment(data:any){
  const payload = {
    clientId: this.authService.$AuthUser.value?.authId,
    cartId: localStorage.getItem('giftCart'),
    itemId: this.clientCart$.value.selectedItems[0].id,
    messageFromSender: data.message,
    senderName: data.senderName,
    recipientEmail: data.recipientEmail,
    recipientName: data.recipientName,
    deliveryDate: data.sendDate
  }; 
  return this.http.post(BASE_URL+'/giftcard_item_email_fulfillment',payload);
}

updateEmailfulfilment(data:any){
  const payload = {
    clientId: this.authService.$AuthUser.value?.authId,
    cartId: localStorage.getItem('giftCart'),
    itemId: this.clientCart$.value.selectedItems[0].id,
    messageFromSender: data.message,
    senderName: data.senderName,
    senderEmail: data.senderEmail,
    recipientEmail: data.recipientEmail,
    recipientName: data.recipientName,
    deliveryDate: data.sendDate
  }; 
  return this.http.post(BASE_URL+'/update_giftcard_item_email_fulfillment',payload);
}

// TODO: update cart client info if user is logged in

// TODO: get email template design
getGiftCardDesigns(){
  if(!this.giftCardDesigns.value){
    const payload = {
      clientId: this.authService.$AuthUser.value?.authId
    }; 
    this.http.post(BASE_URL+'/get_business',payload).pipe(map((response:any)=>{
      return response.data.business.onlineGiftCardSettings.giftCardDesigns.filter((design:any)=> design.selected);
    })).subscribe((res:any)=>{
      if(!res.errors){
        this.giftCardDesigns.next(res);
      }else{
        this.sharedService.showNotification("Error", res.errors[0].message);
      }
    });
  }
}

// TODO: update cart with selected design
setCardDesign(design:any){
  const payload = {
    clientId: this.authService.$AuthUser.value?.authId,
    cartId: localStorage.getItem('giftCart'),
    itemId: this.clientCart$.value.selectedItems[0].id,
    giftCardDesignId: design.id
  }; 
  return this.http.post(BASE_URL+'/set_giftcard_design',payload);
}

// get cart detail
cartDetail(){
  const payload = {
    cartID: localStorage.getItem('giftCart'),
    clientId: this.authService.$AuthUser.value?.authId
  }; 
  return this.http.post(BASE_URL+'/get_cart_detail',payload);
  // .pipe(map((res:any)=>{
  //   res.data.cart.availableCategories[4].availableItems[0].pricePresets.includes(res.data.cart.selectedItems[0].price) ? 
  //   (
  //     res.data.cart.selectedItems[0].taxamount = res.data.cart.selectedItems[0].price/100 * 0.045,
  //     res.data.cart.selectedItems[0].price = res.data.cart.selectedItems[0].price/100 + res.data.cart.selectedItems[0].taxamount
  //   )

  //   : null
  //   return res;
  // }));
}

getCartDetail(){
  const cartId = localStorage.getItem('giftCart');
  if(cartId){
    this.cartDetail().subscribe((res:any)=>{
      if(!res.errors){
        this.clientCart$.next(res.data.cart);
      }else{
        this.sharedService.showNotification("Error", res.errors[0].message);
      }
    });
  }
}

getGiftCardMinMaxPrice(){
  const cartId = localStorage.getItem('giftCart');
  if(cartId){
    const min = this.clientCart$.value?.availableCategories[this.clientCart$.value?.availableCategories?.length - 1]?.availableItems[0]?.giftCardMin
    const max = this.clientCart$.value?.availableCategories[this.clientCart$.value?.availableCategories?.length - 1]?.availableItems[0]?.giftCardMax
    
    return {min: min, max: max}
  }else{
    return {min: 0, max: 0}
  }
}

// TODO: update payment detail

// TODO: update client information
updateClientCartInfo(client:any){
  const payload = {
    "cartId": localStorage.getItem('giftCart'),
    "clientInfo":{
      "email": client.email,
      "firstName":client.firstName,
      "lastName":client.lastName,
      "phoneNumber":client.mobilePhone
    },
    "clientNote":client.note
  }
  return this.http.post(BASE_URL+ '/update_cart_client_info',payload);
}

// TODO: apply promo code
addCartOffer(offerCode:string){
  const payload = {
    "cartId": localStorage.getItem('giftCart'),
    "offerCode":offerCode
  }
  return this.http.post(BASE_URL+ '/add_cart_offer',payload);
}

// TODO: remove promocode
removeCartOffer(offerId:string){
  const payload = {
    "cartId": localStorage.getItem('giftCart'),
    "offerId":offerId
  }
  return this.http.post(BASE_URL+ '/remove_cart_offer',payload);
}

// TODO: checkout cart
selectPaymentMethod(paymentMethodId:string){
  const payload = {
    "cartId": localStorage.getItem('giftCart'),
    "paymentMethodId":paymentMethodId,
    "clientId": this.authService.$AuthUser.value?.authId
  }
  return this.http.post(BASE_URL+ '/select_cart_payment_method',payload);
}

tokenizeCard(card:any){
  const tokenize_url = PAYMENT_API_BASE_URL +  '/cards/tokenize';
  const payload = {
    "card": {
      "name": card.name,
      "number": card.number,
      "cvv": card.cvv,
      "exp_month": card.expiry.substring(0,2),
      "exp_year": card.expiry.substring(3,7),
      "address_postal_code": card.postal_code
    }
  }
  return this.http.post(tokenize_url,payload);
}

addCartPaymentMethod(token:string){
  const payload = {
    "cartId": localStorage.getItem('giftCart'),
    "select":true,
    "token":token
  }
  return this.http.post(BASE_URL+ '/add_cart_card_payment_method',payload);
}

checkoutCart(){
  const payload = {
    "cartId": localStorage.getItem('giftCart'),
    "clientId": this.authService.$AuthUser.value?.authId
  }
  return this.http.post(BASE_URL+ '/checkout_cart',payload);
}

getGiftcardCode(cart_id:string){
  const payload = {
    "cart_id": cart_id
  }
  return this.http.post(BASE_URL+ '/cart_detail_by_id',payload);
}

sendGiftcardEmail(payload:any){
  return this.http.post(BASE_URL+ '/giftcard_purchase',payload);
}

}
