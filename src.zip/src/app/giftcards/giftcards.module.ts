import { NgModule } from '@angular/core';
import { FormsModule,ReactiveFormsModule  }   from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { NgxSkeletonLoaderModule } from 'ngx-skeleton-loader';
import { CommonModule } from '@angular/common';
import { GiftcardsRoutingModule } from './giftcards.routing.module';
import { SharedComponentModule } from '../shared-component/shared-component.module';
import { GiftcardsComponent } from './giftcards.component';
import { GiftcardDetailComponent } from './giftcard-detail/giftcard-detail.component';
import { EmailDesignComponent } from './email-design/email-design.component';
import { ReviewPurchaseComponent } from './review-purchase/review-purchase.component';
import { ThanksComponent } from './thanks/thanks.component';
import { NgxMaskDirective, NgxMaskPipe, provideNgxMask } from 'ngx-mask';
import { PdfComponent } from './pdf/pdf.component';

@NgModule({
  declarations: [
    GiftcardsComponent,
    GiftcardDetailComponent,
    EmailDesignComponent,
    ReviewPurchaseComponent,
    ThanksComponent,
    PdfComponent
  ],
  imports: [
      GiftcardsRoutingModule,
      FormsModule,
      ReactiveFormsModule,
      HttpClientModule,
      NgxSkeletonLoaderModule,
      CommonModule,
      SharedComponentModule,
      NgxMaskDirective,
      NgxMaskPipe,
    ],
  providers: [provideNgxMask()],
  bootstrap: [GiftcardsComponent]
})
export class GiftcardsModule { }