import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { GiftcardsComponent } from "./giftcards.component";
import { ReviewPurchaseComponent } from "./review-purchase/review-purchase.component";
import { ThanksComponent } from "./thanks/thanks.component";
import { AuthGuard } from "src/app/guards/auth.guard";
import { GiftcardDetailComponent } from "./giftcard-detail/giftcard-detail.component";
import { EmailDesignComponent } from "./email-design/email-design.component";
// import { AuthGuard } from "../guards/auth.guard";
// import { AccountComponent } from "./account/account.component";
// import { AppointmentComponent } from "./appointment/appointment.component";
// import { DashboardComponent } from "./dashboard.component";
// import { MembershipProductsComponent } from "./membership-products/membership-products.component";
// import { MembershipsComponent } from "./memberships/memberships.component";
// import { PurchasesComponent } from "./purchases/purchases.component";
// import { RescheduleComponent } from "./reschedule/reschedule.component";
// import { GiftcardsComponent } from "./giftcards/giftcards.component";
// import { ReviewPurchaseComponent } from "./giftcards/review-purchase/review-purchase.component";
// import { ThanksComponent } from "./giftcards/thanks/thanks.component";

@NgModule({
  imports: [
    RouterModule.forChild([
      {
        path: "giftcards",
        component: GiftcardsComponent,
        children: [
          { path: "", redirectTo: "/giftcards/details", pathMatch: 'full' },
          {
            path: "details",
            children: [
              {
                path: "preset/:preset",
                component: GiftcardDetailComponent,
              },
              {
                path: "",
                pathMatch: "full",
                component: GiftcardDetailComponent
              }
            ]
          },
          {
            path: "review",
            component: ReviewPurchaseComponent,
            // canActivate: [AuthGuard]
          },
          {
            path: "thanks",
            component: ThanksComponent,
            // canActivate: [AuthGuard]
          },
        ],
      },
    ]),
  ],
  exports: [RouterModule],
})
export class GiftcardsRoutingModule {}
