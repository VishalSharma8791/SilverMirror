import { Component } from '@angular/core';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-giftcards',
  templateUrl: './giftcards.component.html',
  styleUrls: ['./giftcards.component.scss']
})
export class GiftcardsComponent {
  constructor(private titleService:Title){
    this.titleService.setTitle('Gift Cards - Silver Mirror');
  }
}
