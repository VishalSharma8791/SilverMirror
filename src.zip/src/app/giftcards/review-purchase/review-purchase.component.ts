import { Component, OnInit } from '@angular/core';
import { GiftcardService } from '../giftcards.service';
import { SharedService } from 'src/app/shared-component/shared.service';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/auth/auth.service';
import { TrackingService } from 'src/app/giftcards/tracking.service';

@Component({
  selector: 'app-review-purchase',
  templateUrl: './review-purchase.component.html',
  styleUrls: ['./review-purchase.component.scss']
})
export class ReviewPurchaseComponent implements OnInit {

  cart:any;
  promoCode:any;
  paymentForm!:FormGroup;
  userInfoForm!:FormGroup;
  toggleMobileCart:boolean = false;
  user:any;

  constructor(private authService:AuthService, private trackingService:TrackingService, private router:Router, private formBuilder:FormBuilder, public sharedService:SharedService, public giftCardService:GiftcardService){
    giftCardService.clientCart$.subscribe((cart:any)=>{
      this.cart = cart;
      this.promoCode = cart?.offers.length ? cart?.offers[0].code : null;
      this.applyMotherDayCoupon();
      // if(this.sharedService.getLocalStorageItem('promoCode') && !cart?.offers.length){
      //   this.promoCode = this.sharedService.getLocalStorageItem('promoCode');
      //   this.promoCode.toLowerCase() != 'motherday24' ? this.applyPromoCode() : null;
      // }
    })
    setTimeout(() => {

      this.trackingService.initiateCheckout();
    }, 500);
  }

  ngOnInit(){
    //On reload show cart data[START]
    this.giftCardService.getCartDetail();
    //this.getGiftCardName();
    //On reload show cart data[END]
    this._buildForm();
    this.authService.$AuthUser.subscribe((user:any)=>{
      if(user){
        this._patchAdditionalInfoForm(user);
        this.user = user;
      }
    });
  }

  _patchAdditionalInfoForm(user:any){
    this.userInfoForm.patchValue({
      firstName: user.firstName,
      lastName: user.lastName,
      email: user.email,
      mobilePhone: this.sharedService.getLast10digits(user.mobilePhone) || this.sharedService.getLast10digits(user.phoneNumber),
    });
    // this.userInfoForm.controls.email.disable();
  }

  

  cvvValidator(control: FormControl): { [key: string]: any } | null {
    const valid = /^\d{3,4}$/.test(control.value);
    return valid ? null : { invalidCVV: true };
  }

  expiryValidator(control: FormControl): { [key: string]: any } | null {
    if(control.value){
      const splitVal = control.value.split('/')
      const month = Number(splitVal[0]);
      const year = Number(splitVal[1]);
      const currentYear = new Date().getFullYear();
      const currentMonth = new Date().getMonth() + 1;
      const valid = year >= currentYear && splitVal[0].length && ((currentYear == year && month >= currentMonth) || (year > currentYear && month <= 12));
      return valid ? null : { invalidExpiry: true };
    }else{
      return { invalidExpiry: true };
    }
  }

  maskExpiryDate(expiryDate: string): string {
    // Extract the month and year from the expiry date string
    const [month, year] = expiryDate.split('/');
  
    // Replace the year with asterisks
    const maskedYear = year;
  
    // Concatenate the masked month and year with a forward slash
    const maskedExpiryDate = `${month}/${maskedYear}`;
  
    return maskedExpiryDate;
  }

  onExpiryDateInput(): void {
    // Get the raw input value from the input field
    const rawValue = this.paymentForm.value.expiry.replace(/\D/g, '');

    // Extract the month and year components from the raw input value
    const month = rawValue.substr(0, 2);
    const year = rawValue.substr(2, 4);

    // Mask the expiry date
    const maskedExpiryDate = this.maskExpiryDate(`${month}/${year}`);

    // Update the input field value with the masked expiry date
    this.paymentForm.patchValue({
      expiry:maskedExpiryDate
    });
  }

  _buildForm(){
    // PaymentForm
    this.paymentForm = this.formBuilder.group({
      name: ['', Validators.required],
      number: ['', Validators.compose([Validators.required, Validators.maxLength(19), Validators.minLength(9)])],
      cvv: ['', Validators.compose([Validators.required, Validators.maxLength(4), Validators.minLength(3), this.cvvValidator])],
      expiry: ['', Validators.compose([Validators.required, Validators.maxLength(7), Validators.minLength(7), this.expiryValidator])],
      postal_code: ['', Validators.compose([Validators.required, Validators.maxLength(5), Validators.minLength(5)])],
    });

    // userInfoForm
    this.userInfoForm = this.formBuilder.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      email: ['', Validators.compose([Validators.required, Validators.email])],
      mobilePhone: ['', Validators.compose([Validators.required, Validators.maxLength(10), Validators.minLength(10)])],
    });
  }

  applyPromoCode(){
    if(this.promoCode && this.promoCode != ''){
      if((this.promoCode.toLowerCase() == 'motherday24' && !this.giftCardService.isCustomAmountSelected && this.giftCardService?.selectedGiftCard?.value?.price != 500) || (this.giftCardService.isCustomAmountSelected && this.promoCode.toLowerCase() == 'motherday24')){
        const title = 'Invalid promo code';
        const message = 'Please enter valid promo code';
        return this.sharedService.showNotification(title, message);
      }
      this.giftCardService.addCartOffer(this.promoCode).subscribe((res:any)=>{
        if(!res.errors && res?.data?.addCartOffer?.offer?.applied){
          const title = 'Promo code';
          const message = 'applied successfully';
          this.sharedService.showNotification(title, message);
          localStorage.setItem("promoCode", this.promoCode);
          this.giftCardService.getCartDetail();
        }else{
          const title = 'Invalid promo code';
          const message = 'Please enter valid promo code';
          this.sharedService.showNotification(title, message);
          !res?.data?.addCartOffer?.offer?.applied ? this.giftCardService.removeCartOffer(res?.data?.addCartOffer?.offer?.id).subscribe() : null;
        }
      })
    }
  }

  removePromoCode(){
    let offerId = this.cart?.offers[0].id;
    if(offerId){
      this.giftCardService.removeCartOffer(offerId).subscribe((res:any)=>{
        if(!res.errors){
          const title = 'Promo code';
          const message = 'removed successfully';
          this.sharedService.showNotification(title, message);
          this.giftCardService.getCartDetail();
          this.sharedService.removeLocalStorageItem('promoCode');
          this.promoCode = '';
        }
      })
    }
  }

  selectPaymentMethod(card:any){
    this.giftCardService.selectPaymentMethod(card.id).subscribe((res:any)=>{
      if(!res.errors){
        card.active = true;
        this.giftCardService.getCartDetail();
      }
    })
  }

  updatePaymentMethod(){
    return new Promise((resolve, reject)=>{
      if(this.paymentForm.valid){
        this.giftCardService.tokenizeCard(this.paymentForm.value).subscribe((res:any)=>{
          if(res.token){
            this.giftCardService.addCartPaymentMethod(res.token).subscribe((res:any)=>{
              if(!res.errors){
                // this.bookingService.updateCartDetail();
                resolve(true);
                this.paymentForm.reset();
                // this.togglePaymentMethodForm = false;
              }else{
                reject(res.errors);
              }
            });
          }else{
            reject();
          }
        },err=>{
          let message = 'Please add correct card';
          if(err?.error?.errors?.number_last4?.length){
            message = 'Please check your card number'
            this.paymentForm.controls['number'].setErrors({invalidCard: true});
          }
          const title = 'Incorrect payment information';
          this.sharedService.showNotification(title, message);
          reject(err);
        })
      }else{
        this.paymentForm.markAllAsTouched();
        // reject(false);
        const title = 'Incorrect payment information';
        const message = 'Please add correct card';
        this.sharedService.showNotification(title, message);
      }
    });
  }


  updateSenderNameinEmailFulfilment(){
    const payload = {
      messageFromSender: this.cart?.selectedItems[0]?.emailFulfillment?.messageFromSender,
      senderName: this.userInfoForm.value.firstName + ' ' + this.userInfoForm.value.lastName,
      senderEmail: this.userInfoForm.value.email,
      recipientEmail: this.cart?.selectedItems[0]?.emailFulfillment?.recipientEmail,
      recipientName: this.cart?.selectedItems[0]?.emailFulfillment?.recipientName,
      deliveryDate: this.cart?.selectedItems[0]?.emailFulfillment?.deliveryDate
    }
    this.giftCardService.updateEmailfulfilment(payload).subscribe();
  }

  updateUserInfo(){
    this.updateSenderNameinEmailFulfilment();
    return new Promise((resolve, reject)=>{
      if(this.userInfoForm.valid){
        const client = this.userInfoForm.value;
        client.email = this.userInfoForm.controls['email'].value;
        this.giftCardService.updateClientCartInfo(client).subscribe((res:any)=>{
          if(!res.errors){
            this.cart.clientInformation = res?.data?.updateCart?.cart?.clientInformation;
            resolve(true);
          }else{
            reject();
          }
        });
      }else{
        this.userInfoForm.markAllAsTouched();
        reject();
        const title = 'Incorrect user information';
        const message = 'Please fill the correct sender information';
        this.sharedService.showNotification(title, message);
      }
    })
  }

  removeDiscount(){
    let offerId = this.cart?.offers[0]?.id;
    return new Promise((resolve, reject)=>{
      if(offerId && !this.giftCardService.isCustomAmountSelected){
        this.giftCardService.removeCartOffer(offerId).subscribe((res:any)=>{
          if(!res.errors){
            resolve(true)
          }else{
            reject(false)
          }
        }, err=>{
          reject(false);
        })
      }else{
        resolve(true);
      }
    });
  }

  updateTaxinCart(){
    return new Promise((resolve, reject)=>{
      if(this.isTaxable()){
        let totalAmount = this.calculateTax().subTotal + this.calculateTax().tax - this.calculateTax().discount;
        totalAmount = totalAmount;
        this.giftCardService.selectedGiftCard.next({price: totalAmount});
        this.giftCardService.updateGiftCard().subscribe((res:any)=>{
          if(!res.errors){
            resolve(true);
          }else{
            reject(res.errors);
          }
        });
      }else{
        resolve(true);
      }
    });
  }

  isTaxable(){
    const flag = !this.giftCardService.isCustomAmountSelected && (this.cart?.selectedItems[0]?.price == 11900 || this.cart?.selectedItems[0]?.price == 15900) || this.cart?.selectedItems[0]?.price == 50000 ? true : false;
    return flag;
  }

  calculateTax(){
    let tax = 0;
    let total = 0;
    if(this.isTaxable()){
      tax = this.sharedService.decimalRound(this.cart.summary.total/100 * 0.045);
      total = this.sharedService.decimalRound((this.cart.summary.total / 100) + tax);
    }

    // if(this.cart.summary.discountAmount){
    //   total = (this.cart.summary.subtotal/100 + tax) - (this.cart.summary.discountAmount/100)
    // }else{
    //   total = (this.cart.summary.total / 100) + tax;
    // }

    const res = {
      tax: tax,
      subTotal: this.cart.summary.subtotal/100,
      total: total,
      discount: (this.cart.summary.discountAmount / 100),
      isTaxable: this.isTaxable()
    }
    this.giftCardService.taxdetail = res;

    return res;
    // res.data.cart.availableCategories[4].availableItems[0].pricePresets.includes(res.data.cart.selectedItems[0].price) ? 
  //   (
  //     res.data.cart.selectedItems[0].taxamount = res.data.cart.selectedItems[0].price/100 * 0.045,
  //     res.data.cart.selectedItems[0].price = res.data.cart.selectedItems[0].price/100 + res.data.cart.selectedItems[0].taxamount
  //   )

  //   : null
  //   return res;
  }

  updateCartDetail(){
    return new Promise((resolve, reject)=>{
      this.giftCardService.cartDetail().subscribe((res:any)=>{
        if(!res.errors){
          resolve(true);
          this.giftCardService.clientCart$.next(res.data.cart);
        }else{
          reject();
        }
      });
    })
  }

  easyCheckout(){
    // if(this.cart?.selectedItems[0]?.selectedPaymentMethod?.id){ // If payment method is selected by user
      this.updateUserInfo().then((status:any)=>{
        if(status){
          this.updatePaymentMethod().then((status:any)=>{
            this.removeDiscount().then((status)=>{
              if(status){
                this.updateTaxinCart().then((status:any)=>{
                  if(status){
                    // this.updateCartDetail().then((status:any)=>{
                    //   if(status){
                        this.checkout().then(res=>{
                          this.giftCardService.getCartDetail();
                          const title = 'Glowing Thanks for Your Gift';
                          const message = 'Gift Card purchased successfully';
                          this.sharedService.showNotification(title, message);
                          
                          localStorage.removeItem('recipientType');
                          localStorage.removeItem('giftCart');
                          this.router.navigateByUrl('/giftcards/thanks');
                        }).catch((err=>{
                          const title = 'Checkout Error';
                          const message = err[0].message;
                          this.sharedService.showNotification(title, message);
                          // Reset giftcard amount 
                          this.giftCardService.selectedGiftCard.next({price: this.calculateTax().subTotal});
                          this.giftCardService.updateGiftCard().subscribe();
                          // add discount if present
                          this.applyPromoCode();
                        }));
                    //   }
                    // }).catch(err=>{
                    //   console.log(err);
                    // });
                  }
                })
              }
            })
          });
        }
      }).catch(err=>{
        console.log("client info update error : ", err);
      });
    // }else{
    //   this.paymentForm.markAllAsTouched();
    //   window.scrollTo(0, 0);
    //   this.updateUserInfo().then((status:any)=>{
    //     if(status){
    //       this.updatePaymentMethod().then((status:any)=>{ // If payment method is needed to be add
    //         if(status){
    //           this.removeDiscount().then((status)=>{
    //             if(status){
    //               this.updateTaxinCart().then((status:any)=>{
    //                 if(status){
    //                   this.updateCartDetail().then((status:any)=>{
    //                     if(status){
    //                       this.checkout();
    //                     }
    //                   }).catch(err=>{
    //                     console.log(err);
    //                   });
    //                 }
    //               })
    //             }
    //           })
    //         }
    //       }).catch(err=>{
    //         const title = 'Payment Method Failed';
    //         const message = err[0]?.message;
    //         this.sharedService.showNotification(title, message);
    //       });
    //     }
    //   }).catch(err=>{
    //     console.log("client info update error : ", err);
    //   });
    // }
  }

  checkout(){

    return new Promise((resolve, reject)=>{
      if(this.cart.clientInformation){
        this.giftCardService.checkoutCart().subscribe((res:any)=>{
          if(!res.errors){
            resolve(res);
          }else{
            reject(res.errors);
            //Gift cart payment error [START]
            // var transactionData:any = localStorage.getItem('transactionData');
            // var retrievedTransaction = JSON.parse(transactionData);
            // this.giftCardService.selectedGiftCard.next({price: retrievedTransaction.subTotal});
            // this.cart.selectedItems[0].price =retrievedTransaction.subTotal*100;
            // this.cart.selectedItems[0].lineTotal =retrievedTransaction.subTotal*100;
            // this.cart.selectedItems[0].taxAmount =retrievedTransaction.tax*100;
            // this.cart.summary.total=retrievedTransaction.subTotal*100;
            // this.cart.summary.subtotal=retrievedTransaction.subTotal*100;
            // this.cart.summary.discountAmount=retrievedTransaction.discount*100;
            //Gift cart payment error [END]
          }
        })
      }else{
        const title = 'Sender information is required';
        const message = 'please save the sender information';
        this.sharedService.showNotification(title, message);
      }
    })
  }

  applyMotherDayCoupon(){
    if(!this.giftCardService.isCustomAmountSelected && this.cart?.offers.length && this.giftCardService?.selectedGiftCard?.value?.price != 500 && this.cart?.offers[0]?.code?.toLowerCase() == 'motherday24'){
      this.removePromoCode();
    }else if(!this.giftCardService.isCustomAmountSelected && this.giftCardService?.selectedGiftCard?.value?.price == 500 && !this.cart?.offers.length){
      this.promoCode = 'Motherday24';
      this.applyPromoCode();
    }
  }

  // getGiftCardName(){
  //   const price = this.giftCardService.selectedGiftCard?.value?.price;
  //   switch (price) {
  //     case 115:
  //       localStorage.setItem("giftCartName", "30-Minute Facial");
  //       return '30-Minute Facial'
  //       break;
  //     case 155:
  //       localStorage.setItem("giftCartName", "50-Minute Facial");
  //       return '50-Minute Facial'
  //       break;
  //     default:
  //       localStorage.setItem("giftCartName", "Gift Card");
  //       return 'Gift Card'
  //       break;
  //   }
  // }

}
