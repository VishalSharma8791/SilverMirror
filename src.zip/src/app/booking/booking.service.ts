import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { AuthService } from '../auth/auth.service';
import { SharedService } from '../shared-component/shared.service';
import { environment } from "src/environments";

const BASE_URL = environment.apiBaseURL; 
const PAYMENT_API_BASE_URL = environment.paymentApiBaseURL;

@Injectable({
  providedIn: 'root'
})
export class BookingService {

  constructor(private http:HttpClient, private authService:AuthService, private sharedService:SharedService) { }

  locationList$: BehaviorSubject<any> = new BehaviorSubject([]);
  clientCart$: BehaviorSubject<any> = new BehaviorSubject([]);
  checkoutBookingResponse$: BehaviorSubject<any> = new BehaviorSubject(null);

  mobileCartView:BehaviorSubject<boolean> = new BehaviorSubject(false);

  getLocations() {
    return this.http.get(BASE_URL+'/get_locations');
  }

  createCart(locationId:string, clientMessage?: string, discountCode?: string){
    const payload = {
      locationID:locationId,
      clientMessage:clientMessage,
      discountCode:discountCode,
      client_id:this.authService.$AuthUser.value?.authId
    }; 

    return this.http.post(BASE_URL+'/create_cart', payload);
  }

  getCartDetail(cartID?: string){
    const payload = {
      cartID: cartID || this.sharedService.getLocalStorageItem('cartId'),
      clientId: this.authService.$AuthUser.value?.authId
    }; 
    return this.http.post(BASE_URL+'/get_cart_detail',payload);
  }

  createGuest(){
    const guest = {
      "firstName":"",
      "lastName":"",
      "mobileNumber":"",
      "email":"guest@silvermirror.com"
      }
    const payload = {
      cartID: this.sharedService.getLocalStorageItem('cartId'),
      client: guest,
      client_id: this.authService.$AuthUser.value?.authId
    };
    return this.http.post(BASE_URL+'/create_cart_guest',payload);
  }

  removeGuest(guestId:string){
    let payload = {
      cartId:this.sharedService.getLocalStorageItem('cartId'),
      guestId: guestId,
      clientId:this.authService.$AuthUser.value?.authId
    };
    return this.http.post(BASE_URL+'/remove_cart_guest',payload);
  }

  updateCartDetail(){
    const cartId = this.sharedService.getLocalStorageItem('cartId');
    if(cartId){
      this.getCartDetail().subscribe((res:any)=>{
        if(!res.errors){
          this.clientCart$.next(res.data.cart);
        }
      });
    }
  }

  addItemInCart(item:any){
    const payload = {
      "cartId": this.sharedService.getLocalStorageItem('cartId'),
      "itemGuestId": item.guestId,
      "itemId": item.id,
      "itemStaffVariantId": item.staffId,
      "itemOptionIds": item.itemOptionIds
    }
    return this.http.post(BASE_URL+'/add_item_in_cart',payload);
  }

  addProductToCart(item:any){
    const payload = {
      "cartId": item.id || this.sharedService.getLocalStorageItem('cartId'),
      "itemId": item.itemId,
      "clientId": this.authService.$AuthUser.value?.authId,
      "itemDiscountCode": item.itemDiscountCode
    }
    return this.http.post(BASE_URL+'/add_product_to_cart',payload);
  }

  addAddonInCart(item:any){
    const payload = {
      "cartId": this.sharedService.getLocalStorageItem('cartId'),
      "itemGuestId":item.guestId,
      "itemId": item.id,
      "itemOptionIds": item.optionIds
    }
    return this.http.post(BASE_URL+'/add_service_options_in_cart',payload);
  }

  removeItemInCart(itemId:string){
    const payload = {
      "cartId":this.sharedService.getLocalStorageItem('cartId'),
      "itemId": itemId
    }
    return this.http.post(BASE_URL+'/remove_item_in_cart',payload);
  }

  getScheduleDates(locationId:string, lowerRange:string, upperRange:string, staffIDs:Array<string>){
    const payload = {
      "cartID":this.sharedService.getLocalStorageItem('cartId'),
      "locationID":locationId,
      "timeZone":"America/New_York",
      "searchRangeLower":lowerRange,
      "searchRangeUpper":upperRange,
      "staffVariantIds":staffIDs,
      "clientId": this.authService.$AuthUser.value?.authId
    }
    return this.http.post(BASE_URL + '/get_cart_bookable_dates', payload);
  }

  getScheduleTimes(date:string, staffVariantIds:Array<any>){
    const payload = {
      "cartID":this.sharedService.getLocalStorageItem('cartId'),
      "searchDate":date,
      "timeZone":"America/New_York",
      "clientId": this.authService.$AuthUser.value?.authId,
      "staffVariantIds": staffVariantIds
    }
    return this.http.post(BASE_URL + '/get_cart_bookable_times', payload);
  }

  reserveCartItems(bookableTimeId:string){
    const payload = {
      "cartId":this.sharedService.getLocalStorageItem('cartId'),
      "bookableTimeId":bookableTimeId,
      "clientId": this.authService.$AuthUser.value?.authId
    }
    return this.http.post(BASE_URL + '/reserve_cart_bookable_items', payload);
  }

  getStaffList(){
    const payload = {
      "locationID":this.sharedService.getLocalStorageItem('selectedLocation'),
    }
    return this.http.post(BASE_URL + '/get_staff_by_location', payload);
  }
  
  getCartStaffVarients(bookableTimeId:string, serviceId:string, locationId:string){
    const payload = {
      "cartId":this.sharedService.getLocalStorageItem('cartId'),
      "bookableTimeId":bookableTimeId,
      "serviceId":serviceId,
      "locationId":locationId,
      "clientId": this.authService.$AuthUser.value?.authId
    }
    return this.http.post(BASE_URL + '/get_cart_staff_variants', payload);
  }

  updateItemInCart(itemId:any, staffId:string | null, guestId?:string | null){
    const payload = {
      cartId:this.sharedService.getLocalStorageItem('cartId'),
      itemGuestId: guestId,
      itemId: itemId,
      clientId: this.authService.$AuthUser.value?.authId,
      itemStaffVariantId: staffId
    };
    return this.http.post(BASE_URL+'/update_item_in_cart',payload);
  }

  tokenizeCard(card:any){
    const tokenize_url = PAYMENT_API_BASE_URL + "/cards/tokenize";
    const payload = {
      "card": {
        "name": card.name,
        "number": card.number,
        "cvv": card.cvv,
        "exp_month": card.expiry.substring(0,2),
        "exp_year": card.expiry.substring(3,7),
        "address_postal_code": card.postal_code
      }
    }
    return this.http.post(tokenize_url,payload);
  }

  addCartPaymentMethod(token: string, cartId?: string){
    const payload = {
      "cartId": cartId || this.sharedService.getLocalStorageItem('cartId'),
      "select":true,
      "token":token
    }
    return this.http.post(BASE_URL+ '/add_cart_card_payment_method',payload);
  }

  updateClientCartInfo(client: any, cartId?: string){
    const payload = {
      "cartId": cartId || this.sharedService.getLocalStorageItem('cartId'),
      "clientInfo":{
        "email": client.email,
        "firstName":client.firstName,
        "lastName":client.lastName,
        "phoneNumber":client.mobilePhone
      },
      "clientNote":client.note
    }
    return this.http.post(BASE_URL+ '/update_cart_client_info',payload);
  }

  addCartOffer(offerCode:string, cartId?: string){
    const payload = {
      "cartId": cartId || this.sharedService.getLocalStorageItem('cartId'),
      "offerCode":offerCode
    }
    return this.http.post(BASE_URL+ '/add_cart_offer',payload);
  }

  removeCartOffer(offerId:string, cartId?: string){
    const payload = {
      "cartId": cartId || this.sharedService.getLocalStorageItem('cartId'),
      "offerId":offerId
    }
    return this.http.post(BASE_URL+ '/remove_cart_offer',payload);
  }

  checkoutCart(cartId?: string){
    const payload = {
      "cartId": cartId || this.sharedService.getLocalStorageItem('cartId'),
      "clientId": this.authService.$AuthUser.value?.authId
    }
    return this.http.post(BASE_URL+ '/checkout_cart',payload);
  }

  takeCartOwnership(){
    const payload = {
      "cartId": this.sharedService.getLocalStorageItem('cartId'),
      "clientId": this.authService.$AuthUser.value?.authId
    }
    return this.http.post(BASE_URL+ '/take_cart_ownership',payload);
  }

  selectPaymentMethod(paymentMethodId:string){
    const payload = {
      "cartId":this.sharedService.getLocalStorageItem('cartId'),
      "paymentMethodId":paymentMethodId,
      "clientId": this.authService.$AuthUser.value?.authId
    }
    return this.http.post(BASE_URL+ '/select_cart_payment_method',payload);
  }

  getAppointmentDetail(aptId:string, cartId:string)
  {
    const payload = { 
      "cartId": cartId,
      "appointmentId": aptId,
      "clientId": this.authService.$AuthUser.value?.authId
    }
    return this.http.post(BASE_URL+ '/appointment_detail',payload);
  }

  toggleMobileCart(){
    const mobileCartView = this.mobileCartView.value;
    this.mobileCartView.next(!mobileCartView);
  }

  referralPurchase(invoice_amount:number){
    const payload = {
      "first_name": this.authService.$AuthUser.value?.firstName,
      "last_name": this.authService.$AuthUser.value?.lastName,
      "email": this.authService.$AuthUser.value?.email,
      "invoice_amount": invoice_amount,
      "user_agent": "Silvermirror (https://booking.silvermirror.com)"
    }
    return this.http.post(BASE_URL+ '/purchase',payload);
  }

  invite(){
    const payload = {
      "email": this.authService.$AuthUser.value?.email
    }
    return this.http.post(BASE_URL+ '/invite',payload);
  }

  dateAppointments(date:string){
    const payload = {
      "date": date,
      "location": this.sharedService.getLocalStorageItem('selectedLocation'),
    }
    return this.http.post(BASE_URL+ '/date_appontments',payload);
  }

}
 