import { Pipe, PipeTransform } from "@angular/core";
import { BookingService } from "../../booking.service";
import { SharedService } from "src/app/shared-component/shared.service";

@Pipe({
  name: "addons",
})
export class AddonsPipe implements PipeTransform {

  categoryOrder = [
    {
      category: 'EXFOLIATION ENHANCEMENTS',
      order: 1,
    },
    {
      category: 'CUSTOM-FOR-ALL ENHANCEMENTS',
      order: 2,
    },
    {
      category: 'YOUTHFUL ENHANCEMENTS',
      order: 3,
    },
    {
      category: 'CHEMICAL PEELS',
      order: 4,
    }
  ]

  constructor(private bookingService:BookingService, private sharedService:SharedService){}

  transform(selectedItems: Array<any>, client:any): Array<any> {
    let clientID = client != 'me' ? client.id : null;
    let addons:any = [];
    let items:any = selectedItems.filter((selectedItem:any)=>{
      return selectedItem.guestId == clientID;
    })

    if(items.length){
      addons = items[0].addons;
    }else{
      addons = items;
    }

    this.isAddonAdded(addons, items, clientID);

    return this.categorizeAddons(addons);
  }

  isAddonAdded(addons:Array<any>, selectedItems:Array<any>, clientID:string|null){

    const clientServices = selectedItems.filter(item=> item.guestId == clientID);
    const clientaddons = clientServices.filter(addon=> !addon?.addons?.length);

    clientaddons.map((clientAddon:any)=>{
      addons.map((addon:any)=>{
        addon.id.includes(clientAddon.item.id.replace('urn:blvd:Service:', '')) ? addon.selected = true : null;
      })
    })

  }

  categorizeAddons(addonsList:any) {
    const categories = Array.from(new Set(addonsList.map((option:any) => option.optionGroups[0].name)));
  
    const result = categories.map((category:any) => {
      const addons = addonsList.filter((option:any) => option.optionGroups[0].name === category);
      addons.sort((a:any,b:any)=> Number(this.sharedService.getServiceOrder(a.description)) - Number(this.sharedService.getServiceOrder(b.description)));
      return { category, addons };
    }).sort((a:any, b:any) => {
          const nameA = a.category.toUpperCase();
          const nameB = b.category.toUpperCase();

          const orderA = this.categoryOrder.find(cat=> cat.category.toUpperCase() == nameA)?.order;
          const orderB = this.categoryOrder.find(cat=> cat.category.toUpperCase() == nameB)?.order;

          return Number(orderA) - Number(orderB);
        })
    return result;
  }

}
