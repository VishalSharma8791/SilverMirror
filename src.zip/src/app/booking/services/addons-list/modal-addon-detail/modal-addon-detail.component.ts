import { Component, Input } from '@angular/core';
import { MdbModalRef } from 'mdb-angular-ui-kit/modal';
import { Observable } from 'rxjs';
import { BookingService } from 'src/app/booking/booking.service';
import { TrackingService } from 'src/app/booking/tracking.service';
import { SharedService } from 'src/app/shared-component/shared.service';

@Component({
  selector: 'app-modal-addon-detail',
  templateUrl: './modal-addon-detail.component.html',
  styleUrls: ['./modal-addon-detail.component.scss']
})
export class ModalAddonDetailComponent {

  @Input() addon:any;
  @Input() client:any;

  cart:any;
  cartSubscription:any;

  constructor(private trackingService:TrackingService, public sharedService:SharedService, private bookingService:BookingService, public addonModalRef: MdbModalRef<ModalAddonDetailComponent>){
    this.cartSubscription = this.bookingService.clientCart$.subscribe((cart:any)=>{
      if(cart){
        this.cart = cart;
      }
    });
  }

  addAddon(guestId:string|null){
    if(!this.addon.selected){
      const payload = {
        id:this.addon.id,
        staffId:null,
        guestId:guestId
      }
      this.bookingService.addItemInCart(payload).subscribe((res:any)=>{
        if(!res.errors){
          this.addon.category = 'addon';
          this.trackingService.addItem(this.addon);
          const title = 'Great choice! Looking gorgeous…';
          const message = 'ADDED TO CART';
          this.addonModalRef.close();
          this.sharedService.showNotification(title, message);
          this.bookingService.updateCartDetail();
        }else{
          this.sharedService.showNotification('Errors', res.errors[0].message);
        }
      });
    }else{
      const title = 'Add-on already added';
      const message = 'please choose another add-on to add in cart';
      this.sharedService.showNotification(title, message);
    }
  }

  addAddonForAll(){
    let isSameService = this.sharedService.getLocalStorageItem('isSameService');
    if(isSameService == 'false'){
      this.addAddon(null);
      let guests = this.cart.guests;
      guests.map((guest:any)=>{
        this.addAddon(guest.id);
      })
    }else{
      this.addAddon(this.client.id)
    }
  }

}
 