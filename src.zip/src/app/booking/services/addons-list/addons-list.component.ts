import { Component, Input } from '@angular/core';
import { MdbModalRef, MdbModalService } from 'mdb-angular-ui-kit/modal';
import { SharedService } from 'src/app/shared-component/shared.service';
import { BookingService } from '../../booking.service';
import { ModalAddonDetailComponent } from './modal-addon-detail/modal-addon-detail.component';
import { TrackingService } from '../../tracking.service';

@Component({
  selector: 'app-addons-list',
  templateUrl: './addons-list.component.html',
  styleUrls: ['./addons-list.component.scss']
})
export class AddonsListComponent {

  @Input() cart:any;
  @Input() client:any;

  serviceDetailModalRef!: MdbModalRef<ModalAddonDetailComponent> | null;
  modalConfig: any = {
    animation: true,
    backdrop: true,
    containerClass: "right",
    data: {},
    ignoreBackdropClick: false,
    keyboard: true,
    modalClass: "modal-top-right",
  }; 

  constructor(private trackingService:TrackingService, public sharedService:SharedService, private bookingService:BookingService, private modalService: MdbModalService){}

  addAddon(service:any, guestId:string|null){
    if(!service.selected){
      const payload = {
        id:service.id,
        staffId:null,
        guestId:guestId
      }
      this.bookingService.addItemInCart(payload).subscribe((res:any)=>{
        if(!res.errors){
          service.category = 'addon';
          this.trackingService.addItem(service);
          const title = 'Great choice! Looking gorgeous…';
          const message = 'ADDED TO CART';
          this.sharedService.showNotification(title, message);
          this.bookingService.updateCartDetail();
        }else{
          this.sharedService.showNotification('Errors', res.errors[0].message);
        }
      });
    }else{
      const title = 'Add-on already added';
      const message = 'please choose another add-on to add in cart';
      this.sharedService.showNotification(title, message);
    }
  }

  addAddonForAll(addon:any){
    let isSameService = this.sharedService.getLocalStorageItem('isSameService');
    if(isSameService == 'false'){
      this.addAddon(addon, null);
      let guests = this.cart.guests;
      guests.map((guest:any)=>{
        this.addAddon(addon, guest.id);
      })
    }else{
      this.addAddon(addon, this.client.id)
    }
  }

  addonDetail(addon: any) {
    this.modalConfig.data.addon = addon;
    this.modalConfig.data.client = this.client;
    this.serviceDetailModalRef = this.modalService.open(
      ModalAddonDetailComponent,
      this.modalConfig
    );
    addon.category = 'addon';
    this.trackingService.viewItem(addon);
  }

}
 