import { Component, Input } from '@angular/core';
import { MdbModalRef } from 'mdb-angular-ui-kit/modal';
import { Observable } from 'rxjs';
import { BookingService } from 'src/app/booking/booking.service';
import { TrackingService } from 'src/app/booking/tracking.service';
import { SharedService } from 'src/app/shared-component/shared.service';

@Component({
  selector: 'app-modal-service-detail',
  templateUrl: './modal-service-detail.component.html',
  styleUrls: ['./modal-service-detail.component.scss']
})
export class ModalServiceDetailComponent {

  @Input() service:any;
  @Input() client:any;

  cart:any;
  cartSubscription:any;

  constructor(private trackingService:TrackingService, public sharedService:SharedService, private bookingService:BookingService, public serviceModalRef: MdbModalRef<ModalServiceDetailComponent>){
    this.cartSubscription = this.bookingService.clientCart$.subscribe((cart:any)=>{
      if(cart){
        this.cart = cart;
      }
    })
    setTimeout(() => {
      this.service.description.replace('/n','<br />');
    }, 1000);
  }

  isBaseServiceAdded(){
    let selected:boolean = false;
    this.cart.selectedItems.map((selectedItem:any)=>{
      if(this.client != 'me'){
        selectedItem.guestId == this.client.id ? selected = true : null;
      }else{
        selectedItem.guestId == null ? selected = true : null;
      }
    })
    return selected;
  }

  canAddHydrafacial(){
    const hydrafcialServices = this.cart.selectedItems.filter((item:any)=>{
      return item.item.name.toLowerCase().includes('hydrafacial');
    });
    return hydrafcialServices.length && this.service.name.toLowerCase().includes('hydrafacial') ? false : true;
  }

  addService(){
    

    if(!this.isBaseServiceAdded()){
      if(this.canAddHydrafacial()){
        const payload = {
          id: this.service.id,
          staffId:null,
          guestId:this.client != 'me' ? this.client.id : null
        }
        this.bookingService.addItemInCart(payload).subscribe((res:any)=>{
          if(!res.errors){
            this.trackingService.addItem(this.service);
  
            const title = 'Great choice! Looking gorgeous…';
            const message = 'ADDED TO CART';
            this.cartSubscription.unsubscribe();
            this.serviceModalRef.close();
            this.sharedService.showNotification(title, message);
            this.bookingService.updateCartDetail();
          }else{
            this.sharedService.showNotification('Errors', res.errors[0].message);
          }
        });
      }else{
        const title = 'Please select another service.';
        const message = 'Unfortunately, this service cannot be booked for more than one guest at a time.';
        return this.sharedService.showNotification(title, message);
      }
    }else{
      const title = 'Facials, Microneedling and Chemical Peels cannot be performed together';
      const message = 'Please remove existing service from cart';
      return this.sharedService.showNotification(title, message);
    }
  }

  addAddons(){
    this.serviceModalRef.close({addAddons : true});
  }

  getServiceName(name:string){
    return name.replace('(', '<br/>(');
  }

}
