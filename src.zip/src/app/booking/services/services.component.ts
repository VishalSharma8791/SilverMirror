import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MdbModalRef, MdbModalService } from 'mdb-angular-ui-kit/modal';
import { SharedService } from 'src/app/shared-component/shared.service';
import { BookingService } from '../booking.service';
import { ModalAddonsComponent } from './modal-addons/modal-addons.component';
import { ModalIsAddonAddedComponent } from './modal-is-addon-added/modal-is-addon-added.component';
import { TrackingService } from '../tracking.service';

@Component({
  selector: 'app-services',
  templateUrl: './services.component.html',
  styleUrls: ['./services.component.scss']
})
export class ServicesComponent implements OnInit {

  tabs:{
    timeFilters:string;
    guest:any;
    service:string;
  } = {
    timeFilters: '30',
    guest:'me',
    service:'Facials 30 Minutes'
  }
  resetServiceTabs:any;
  resetTimeTabs:any;
  serviceFilter:string='Facials 30 Minutes'
  cart:any;
  isSameServices:any = false;
  isGuestTabVisible:boolean = true;
  addonModalRef!: MdbModalRef<ModalAddonsComponent> | null;
  isAddonAddedModalRef!: MdbModalRef<ModalIsAddonAddedComponent> | null;
  modalConfig: any = {
    animation: true,
    backdrop: true,
    containerClass: "right",
    data: {},
    ignoreBackdropClick: false,
    keyboard: true,
    modalClass: "modal-top-right",
  };

  cartSubscription1:any;

  constructor(private trackingService:TrackingService, public bookingService:BookingService, private sharedService:SharedService, private router:Router, private modalService: MdbModalService){
    bookingService.updateCartDetail();
    this.cartSubscription1 = bookingService.clientCart$
    
    this.cartSubscription1.subscribe((cart:any)=>{
      if(cart){
        this.cart = cart;
        this.getMemberAddedServiceCount;
        this.serviceAddRequested();
      }
    })
  }

  ngOnInit(): void {
      // this.serviceAddRequested();
  }

  ngAfterViewInit() {
    setTimeout(() => {
      this.isSameServiceLocal();
    }, 500);
  }

  // ngDestroy(){
  //   this.cartSubscription1.unsubscribe();
  // }

  serviceAddRequested(){
    const serviceName = this.sharedService.getLocalStorageItem('serviceName');
    if(serviceName && this.cart && this.cart.id){
      // let cartSubscription2 = this.bookingService.clientCart$;
    
      // cartSubscription2.subscribe((cart)=>{
        // if(cart && cart.id){
          const service = this.sharedService.findServiceIdByName(serviceName, this.cart);
          this.sharedService.removeLocalStorageItem('serviceName');
          // cartSubscription2.unsubscribe();
          service ? this.addService(service) : null;
        // }
      // });
    }
  }

  isSameServiceLocal(){
    let flag = this.sharedService.getLocalStorageItem('isSameService');
    if(!flag || flag == 'true'){
      this.isSameServices = true;
      this.isGuestTabVisible = true;
    }else if(flag == 'false'){
      this.isSameServices = false;
      this.hideGuestTabs();
    }
  }

  showAddons(){
    this.tabs.service = 'addon';
    this.changeServiceTab('addon');
    this.resetServiceTabs = {event:true, currentTab:'addon'};
    setTimeout(() => {
      this.resetServiceTabs = {event:false, currentTab:'addon'};
    }, 1000);
  }

  changeServiceTab(ev:any){
    if(ev == 'facial'){
      this.tabs.service = 'Facials 30 Minutes';  
    }else if(ev !='addon'){
      this.tabs.service = ev;
    }else if (ev == 'addon'){
      let selectedItems;
      if(this.tabs.guest != 'me'){
        selectedItems = this.cart.selectedItems.filter((item:any)=>item.guestId == this.tabs.guest.id);
      }else{
        selectedItems = this.cart.selectedItems.filter((item:any)=>item.guestId == null);
      }
      
      if(selectedItems.length){
        this.tabs.service = 'addon';
      }else{
        this.resetServicesTab();
        const title = 'Service not added';
        const message = 'Please add a service first';
        this.sharedService.showNotification(title, message);
      }
    }
  }

  resetServicesTab(){
    let currentTab:string = '';
    if(this.tabs.service.toLowerCase().includes('facial')){
      currentTab = 'facial';
      this.resetTimeTab();
    }else if(this.tabs.service == 'addon'){
      currentTab = 'facial';
      this.resetTimeTab();
    }else{
      currentTab = this.tabs.service;
    }
    this.resetServiceTabs = {event:true, currentTab:currentTab};
    setTimeout(() => {
      this.resetServiceTabs = {event:false, currentTab:currentTab};
    }, 1000);
  }

  resetTimeTab(){
    this.resetTimeTabs = '30';
    setTimeout(() => {
      this.resetTimeTabs = null;
    }, 1000);
  }

  changeGuestTab(ev:any){
    if(this.tabs.service == 'addon'){
      let selectedItems;
      if(ev != 'me'){
        selectedItems = this.cart.selectedItems.filter((item:any)=>item.guestId == ev.id);
      }else{
        selectedItems = this.cart.selectedItems.filter((item:any)=>item.guestId == null);
      }
      if(selectedItems && selectedItems.length){
        this.tabs.guest = ev;
      }else{
        this.resetServicesTab();
        const title = 'Service not added';
        const message = 'Please add a service first';
        this.sharedService.showNotification(title, message); 
      }
    }
    this.tabs.guest = ev;
  }

  changeTimeFilterTab(ev:any){
    this.tabs.timeFilters = ev;
    if(ev == '30'){
      this.tabs.service = 'Facials 30 Minutes'
    }else if(ev == '50'){
      this.tabs.service = 'Facials 50 Minutes'
    }
  }

  addService(service:any){
    let selected:boolean = false;
    let canBook:boolean = true;
    this.cart.selectedItems.map((selectedItem:any)=>{
      if(service.name.toLowerCase().includes('hydrafacial') && selectedItem.item.name.toLowerCase().includes('hydrafacial')){
        canBook = false;
        const title = 'Please select another service.';
        const message = 'Unfortunately, this service cannot be booked for more than one guest at a time.';
        return this.sharedService.showNotification(title, message);
      }else {
        if(this.tabs.guest != 'me'){
          selectedItem.guestId == this.tabs.guest.id ? selected = true : null;
        }else{
          selectedItem.guestId == null ? selected = true : null;
        }
      }
    })
    
    if(!selected && canBook){
      const payload = {
        id:service.id,
        staffId:null,
        guestId:this.tabs.guest != 'me' ? this.tabs.guest.id : null
      }
      this.bookingService.addItemInCart(payload).subscribe((res:any)=>{
        if(!res.errors){
          service.category = this.tabs.service;
          this.trackingService.addItem(service);
          
          const title = 'Great choice! Looking gorgeous…';
          const message = 'ADDED TO CART';
          this.sharedService.showNotification(title, message);
          this.bookingService.updateCartDetail();
        }else{
          this.sharedService.showNotification('Errors', res.errors[0].message);
        }
      });
    }else{
      const title = 'Facials, Microneedling and Chemical Peels cannot be performed together';
      const message = 'Please remove existing service from cart';
      this.sharedService.showNotification(title, message);
    }
  }

  itemRemovedFromCart(){
    // runs when item is removed from cart
    this.isSameServiceLocal();
    setTimeout(() => {
      this.resetServiceTabs = {event:true, currentTab:'facial'};
    }, 1000);
  }

  // isAnyAddonAdded(){
  //   let flag = false;
  //   let catNames = [];
  //   this.cart.selectedItems.map((selectedItem:any) => {
  //     const catName = this.sharedService.getServiceCategoryName(selectedItem, this.cart.availableCategories);
  //     catName != '' ? catNames.push(catName) : null;
  //     if(selectedItem.selectedOptions.length > 0){
  //       flag = true;
  //     }
  //   });
  //   if(!catNames.length){
  //     flag = true;
  //   }
  //   return flag;
  // }

  get getMemberAddedServiceCount(){
    // let count = 0;
    if(this.cart.guests && this.cart.guests.length){
      this.cart.guests.map((guest:any)=>{
        if(this.cart && this.cart.selectedItems && this.cart.selectedItems.length){
          let selectedItems = this.cart.selectedItems.filter((selectedItem:any)=>{
            return selectedItem.guestId == guest.id
          });
          guest.addedServiceCount = selectedItems.length;
          // selectedItems.map((selectedItem:any)=>{
          //   ++count;
          //   count = count + selectedItem.selectedOptions.length;
          //   guest.addedServiceCount = count;
          //   count = 0;
          // });
        }
      });
      let meAsGuest = {"label":"me", "addedServiceCount": 0};
      let selectedItems = this.cart.selectedItems.filter((selectedItem:any)=>{
        return selectedItem.guestId == null
      });
      meAsGuest.addedServiceCount = selectedItems.length;
      // selectedItems.map((selectedItem:any)=>{
      //   ++count;
      //   count = count + selectedItem.selectedOptions.length;
      //   meAsGuest.addedServiceCount = count;
      //   count = 0;
      // });
      return [...this.cart.guests, meAsGuest];
    }
    return [];
  }

  get getTotalAddedServiceCount(){
    let count = 0;
    if(this.cart && this.cart.selectedItems){
      count = this.cart.selectedItems.length;
      // if(selectedItems && selectedItems.length){
      //   selectedItems.map((selectedItem:any)=>{
      //     ++count;
      //     count = count + selectedItem.selectedOptions.length;
      //   })
      // }
    }
    return count;
  }

  hideGuestTabs(){
    this.isGuestTabVisible = false;
  }

  groupObjectsById(array:any) {
    const groups:any = {};
    
    for (const obj of array) {
      if (obj.guestId in groups) {
        groups[obj.guestId].data.push(obj);
      } else {
        groups[obj.guestId] = { guestId: obj.guestId, guest: obj.guest, data: [obj] };
      }
    }
    
    return Object.values(groups);
  }

  get getGroupedServices(){
    const groupedSelectedServices:any = this.groupObjectsById(this.cart.selectedItems);
    return groupedSelectedServices;
  }

  copyItemsToGuest(){
    this.sharedService.setLocalStorageItem("isSameService", this.isSameServices.toString());
    if(!this.isSameServices && this.getGroupedServices.length === 1 && this.canAddHydrafacial()){
      this.hideGuestTabs();
      const guests = this.cart.guests;

      // const mySelectedItems = this.cart.selectedItems.filter((selectedItem:any)=> selectedItem.guestId == null);
      // let mySelectedModifiers:any = [];
      // this.cart.selectedItems.filter((selectedItem:any)=> {
      //   if(selectedItem.guestId == null){
      //     let ids = selectedItem.selectedOptions.map((option:any)=> option.id);
      //     mySelectedModifiers = ids
      //   }
      // });

      const mySelectedBaseService = this.getGroupedServices.filter((groupService:any)=>groupService.guestId == null)[0]?.data.filter((service:any)=>!service.item.optionGroups.length);
      const mySelectedAddons = this.getGroupedServices.filter((groupService:any)=>groupService.guestId == null)[0]?.data.filter((service:any)=>service.item.optionGroups.length);

      if(this.getGroupedServices?.length == 1 && this.getGroupedServices[0]?.guestId == null){
        guests.forEach((guest:any)=>{
          const payload = {
            id:mySelectedBaseService[0]?.item?.id,
            staffId:null,
            guestId: guest.id
          }
          this.bookingService.addItemInCart(payload).subscribe((res:any)=>{
            if(!res.errors){

              // update cart locally
              let tempCart = this.bookingService.clientCart$.value;
              tempCart.selectedItems = res.data.addCartSelectedBookableItem.cart.selectedItems;
              this.bookingService.clientCart$.next(tempCart);
              
              const guestBaseService = res.data.addCartSelectedBookableItem.cart.selectedItems.filter((guestSelectedItem:any)=>guestSelectedItem.guestId == guest.id)[0];
              mySelectedAddons.forEach((myAddon:any) => {
                const addonID = 'urn:blvd:ServiceAddon:' + myAddon.item.id.replace('urn:blvd:Service:', '') + ':' + guestBaseService.id.replace('urn:blvd:Service:', '');
                const addonPayload = {
                  id:addonID,
                  staffId:null,
                  guestId: guest.id
                }
                this.bookingService.addItemInCart(addonPayload).subscribe((res:any)=>{
                  if(!res.errors){
                    // update cart locally
                    let tempCart = this.bookingService.clientCart$.value;
                    tempCart.selectedItems = res.data.addCartSelectedBookableItem.cart.selectedItems;
                    this.bookingService.clientCart$.next(tempCart);
                  }
                });
              });
            }
          });
        })
      }else{
        const title = 'Service already added for guest';
        const message = 'Please remove the guest services to copy my services';
        this.sharedService.showNotification(title, message);
      }
      
      // if(this.cart.selectedItems.length == 1){
      //   // Add items in cart
      //   guests.forEach((guest:any)=>{
      //     const payload = {
      //       id:mySelectedItems.item.id,
      //       staffId:null,
      //       guestId: guest.id,
      //       itemOptionIds: mySelectedModifiers
      //     }
      //     this.bookingService.addItemInCart(payload).subscribe((res:any)=>{
      //       if(!res.errors){
      //         this.bookingService.updateCartDetail();
      //       }
      //     });
      //   })
      // }
      // else{
      //   const title = 'Sevice already added for guest';
      //   const message = 'Please remove the guest services to copy my services.';
      //   this.sharedService.showNotification(title, message);
      // }
    }else{
      this.isGuestTabVisible = true;
    }
  }

  canAllowDifferentService(){
    if(!this.getGroupedServices.filter((groupService:any)=>groupService.guestId == null).length){
      const title = 'You have not added any service yet';
      const message = 'Please add a service for yourself first';
      this.sharedService.showNotification(title, message);
    }
    if(!this.canAddHydrafacial()){
      // this.isSameServices = !this.isSameServices;
      const title = 'Please select another service.';
      const message = 'Unfortunately, this service cannot be booked for more than one guest at a time.';
      return this.sharedService.showNotification(title, message);
    }
    if(this.isSameServices && this.getGroupedServices.length > 1){
      const title = 'Sevice already added for guest';
      const message = 'Please remove the guest services to copy my services';
      this.sharedService.showNotification(title, message);
    }else if(this.getGroupedServices.length < 1){
      const title = 'You have not added any service yet';
      const message = 'Please add a service for yourself first';
      this.sharedService.showNotification(title, message);
    }
  }

  setCurrentClient(){
    return this.cart.selectedItems.map((selectedItem:any)=>{
      if(selectedItem.guestId == null && selectedItem.addons.length){
        return 'me'
      }else if(selectedItem.guestId != null && selectedItem.addons.length){
        return selectedItem.guest;
      }
    }).filter((n:any) => n)[0];
  }

  canShowAddonPopup(){
    let isAddonAdded:boolean = false;
    let serviceWithAddon:boolean = false;

    let flag = false;
    this.cart.selectedItems.forEach((element:any) => {
      const isService = !element.item.optionGroups.length;
      if(!isService){
        isAddonAdded = true;
      }else if(isService && element.addons.length){
        serviceWithAddon = true;
      }
    });

    !isAddonAdded && serviceWithAddon ? flag = true : flag = false;
    return flag
  }

  canAddHydrafacial(){
    const hydrafcialServices = this.cart.selectedItems.filter((item:any)=>{
      return item.item.name.toLowerCase().includes('hydrafacial');
    });
    return hydrafcialServices.length ? false : true;
  }

  continue(){
    window.scrollTo(0, 0);
    // toggleCart ? this.bookingService.toggleMobileCart() : null;
    let cartMemberCount = this.cart.guests.length + 1;
    if(this.cart.selectedItems.length){
      if(this.getGroupedServices.length == cartMemberCount){
       
        if(this.canShowAddonPopup()){
          // this.isAddonAddedModalRef = this.modalService.open(
          //   ModalIsAddonAddedComponent,
          //   this.modalConfig
          // );
          // this.isAddonAddedModalRef.onClose.subscribe((choice:any)=>{
            // if(choice && choice.choice){
              // show addon popup
              // this.modalConfig.data.selectedItem = this.cart.selectedItems.filter((item:any)=> item.addons.length > 0).filter((item:any)=> (this.tabs.guest == 'me' ? item.guestId == null : item.guestId == this.tabs.guest.id));
              this.modalConfig.data.currentClient = this.setCurrentClient();
              this.modalConfig.data.cart = this.cart;
              this.modalConfig.data.isSameService = this.isSameServices;
              this.addonModalRef = this.modalService.open(
                ModalAddonsComponent,
                this.modalConfig
              );

              this.addonModalRef.onClose.subscribe(()=>{
                this.router.navigateByUrl('/booking/schedule');
              })

              // this.bookingService.mobileCartView.next(false);
              // this.changeServiceTab('addon');
              // this.resetServiceTabs = {event:true, currentTab:'addon'};
              // setTimeout(() => {
              //   this.resetServiceTabs = {event:false, currentTab:'addon'};
              // }, 1000);
            // }else{
            //   this.router.navigateByUrl('/booking/schedule');
            // }
          // })
        }else{
          this.bookingService.mobileCartView.next(false);
          this.router.navigateByUrl('/booking/schedule');
        }
      }else{
        const title = 'Service not added for member';
        const message = 'Please add the service for all members';
        this.sharedService.showNotification(title, message);  
      }
    }else{
      const title = 'Cart is empty';
      const message = 'Add service to continue';
      this.sharedService.showNotification(title, message);
    }
  }

}