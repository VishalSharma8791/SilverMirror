import { Component } from '@angular/core';

@Component({
  selector: 'app-mobile-services-tabs',
  templateUrl: './mobile-services-tabs.component.html',
  styleUrls: ['./mobile-services-tabs.component.scss']
})
export class MobileServicesTabsComponent {

}
