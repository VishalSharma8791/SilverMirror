import { Component, Input } from '@angular/core';
import { MdbModalRef } from 'mdb-angular-ui-kit/modal';
import { forkJoin } from 'rxjs';
import { SharedService } from 'src/app/shared-component/shared.service';
import { BookingService } from '../../booking.service';

@Component({
  selector: 'app-modal-addons',
  templateUrl: './modal-addons.component.html',
  styleUrls: ['./modal-addons.component.scss']
})
export class ModalAddonsComponent {

  @Input() selectedItem:any = [];
  @Input() currentClient:any;
  @Input() cart:any;
  @Input() isSameService!:boolean;

  selectedAddons:any = [];
  guests:any = [{id: null, label: "Me"}];
  meCheckbox:boolean = true;

  constructor(private bookingService: BookingService, public sharedService:SharedService, public addonModalRef: MdbModalRef<ModalAddonsComponent>){
    setTimeout(() => {
      if(this.cart){
        this.guests = [...this.guests, ...this.cart.guests];
        this.clientAddons();
      }
    }, 200);
  }

  setCurrentClient(){
    this.cart.selectedItems.map((selectedItem:any)=>{
      if(selectedItem.guestId == null && selectedItem.addons.length){
        this.currentClient = 'me'
      }else if(selectedItem.guestId != null && selectedItem.addons.length){
        this.currentClient = selectedItem.guest;
      }
    })
  }

  clientAddons(){
    this.guests.map((guest:any)=>{
      guest.enabled = false;
      guest.selected = false;
      this.cart.selectedItems.map((item:any)=>{
        if(guest.id == item.guestId && item.addons.length){
          this.currentClient = guest;
          guest.enabled = true;
          guest.selected = true;
        }
      })
    })
  }


  addAddon(service?:any){
    const { selectedAddons } = this.getSelectedAddons();
    let requests:any = [];
    this.guests.forEach((client:any) => {
      if(client.enabled && client.selected){
        const selectedItem = this.cart.selectedItems.filter((selectedItem:any)=> selectedItem.guestId == client.id)[0];
        selectedAddons.forEach((addon:any) => {
          const substring = addon.id.substring(addon.id.lastIndexOf(':'));
          const addonId = addon.id.replace(substring, selectedItem.id.replace('urn:blvd:Service', ''));
          const payload = {
            id: addonId,
            staffId:null,
            guestId:client.id
          }
          requests.push(this.bookingService.addItemInCart(payload));
        });
      }
    });

    forkJoin(requests).subscribe(res=>{
      const title = 'Great choice! Looking gorgeous…';
      const message = 'ADDED TO CART';
      this.sharedService.showNotification(title, message);
      this.addonModalRef.close()
      this.bookingService.updateCartDetail();
    })

    // if(!service.selected){
    //   const payload = {
    //     id:service.id,
    //     staffId:null,
    //     guestId:this.selectedItem.guestId
    //   }
    //   this.bookingService.addItemInCart(payload).subscribe((res:any)=>{
    //     if(!res.errors){
    //       const title = 'Great choice! Looking gorgeous…';
    //       const message = 'ADDED TO CART';
    //       this.sharedService.showNotification(title, message);
    //       this.bookingService.updateCartDetail();
    //     }else{
    //       this.sharedService.showNotification('Errors', res.errors[0].message);
    //     }
    //   });
    // }else{
    //   const title = 'Add-on already added';
    //   const message = 'please choose another add-on to add in cart.';
    //   this.sharedService.showNotification(title, message);
    // }
  }

  selectAddon(addon:any){
    addon.isSelectToAdd = !addon.isSelectToAdd
  }

  getSelectedAddons(){
    const addons = this.cart.selectedItems.filter((selectedItem:any)=> selectedItem.guestId == this.currentClient.id)[0].addons.filter((addon:any)=> addon.isSelectToAdd);

    return {selectedAddons: addons, count: addons.length}
  }

  canChangeClient(guest:any){
    if(this.isSameService && guest.enabled){
      return true;
    }else {
      return false;
    }
  }

  validatePopup(){
    let isGuestSelected:boolean = false;
    this.guests.filter((guest:any)=> guest.selected).length ? isGuestSelected = true : isGuestSelected = false;

    if(!isGuestSelected){
      const title = 'Please select the user';
      const message = 'You have not selected any user to add addons';
      this.sharedService.showNotification(title, message);
    }else if(this.getSelectedAddons().count < 1){
      const title = 'Please select addons';
      const message = 'You have not selected any addons';
      this.sharedService.showNotification(title, message);
    }else{
      this.addAddon();
    }
  }

}
