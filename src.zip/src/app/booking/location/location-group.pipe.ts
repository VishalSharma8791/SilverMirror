import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'locationGroup'
})
export class LocationGroupPipe implements PipeTransform {

  transform(collection: any[], property: string): any[] {
    const groupedCollection = Object.entries(collection.reduce((previous, current)=> {
      const city = current.node.address.city;
      if (previous[city]) {
        previous[city].push(current.node);
      } else {
        previous[city] = [current.node];
      }

        return previous;
    }, {})).map(([key, value]) => ({ key, value }));

    console.log("grouped collection :: ", groupedCollection);

    if(groupedCollection.length >= 2) {
      const temp = groupedCollection[0]
      groupedCollection[0] = groupedCollection[groupedCollection.length - 2];
      groupedCollection[groupedCollection.length - 2] = temp;
    }
    return groupedCollection;
  }
}
