import { Component, OnInit } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { AuthService } from "src/app/auth/auth.service";
import { RebookService } from "src/app/dashboard/rebook.service";
import { Notification, NotificationService } from "src/app/notification.service";
import { SharedService } from "src/app/shared-component/shared.service";
import { BookingService } from "../booking.service";

@Component({
  selector: "app-location",
  templateUrl: "./location.component.html",
  styleUrls: ["./location.component.scss"],
})
export class LocationComponent implements OnInit {

  currentIndex: any;
  isActive = false;
  lastAppointment:any = [];
  paramLocation!:string;

  constructor(private route: ActivatedRoute, public rebookService:RebookService, public authService:AuthService, public bookingService:BookingService, private notificationService:NotificationService, public sharedService:SharedService, private router:Router) {
    this.getLocations();
    authService.$AuthUser.value ? this.rebookService.getLastAppointment() : null;
    rebookService.$lastAppointment.subscribe(data=>{
      this.lastAppointment = data;
    })
  }

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      const couponCode = params['coupon'];
      const serviceName = params['service'];
      this.paramLocation = params['location'];
      couponCode ? this.sharedService.setLocalStorageItem('coupon', couponCode) : null;
      serviceName ? this.sharedService.setLocalStorageItem('serviceName', serviceName) : null;
    });
  }

  getLocations(){
    if(!this.bookingService.locationList$.value.length){
      this.bookingService.getLocations().subscribe((res: any) => {
        if(!res.errors){
          this.bookingService.locationList$.next(res.data.locations.edges);
          this.setParamLocation()
        }else{
          this.sharedService.showNotification("Error", res.errors[0].message);
        }
      });
    }
  }

  setParamLocation(){
    if(this.paramLocation){
      const loc = this.bookingService.locationList$.value.filter((loc:any)=> loc.node.name.replaceAll(' ','-').toLowerCase() == this.paramLocation.replaceAll(' ','-').toLowerCase())
      loc.length ? this.createCart(loc[0].node.id) : null;
    }
  }
  
  expand(index: any) {
    if (this.currentIndex === index) {
      this.currentIndex = null;
      return;
    }
    this.currentIndex = index;
  }
  
  locationSelected(id: any) {
    const location = this.sharedService.getLocalStorageItem("selectedLocation");
    return location && location == id ? "active" : '';
  }

  createCart(id:string){
    this.bookingService.createCart(id).subscribe((res:any)=>{
      if(!res.errors){
        this.sharedService.setLocalStorageItem('selectedLocation', id);
        this.sharedService.setLocalStorageItem('cartId', res.data.createCart.cart.id);
        this.router.navigateByUrl('/booking/whoscoming');
        this.bookingService.updateCartDetail();
      }else{
        this.sharedService.showNotification("Error", res.errors[0].message);
      }
    });
  }

  selectLocation(id:any){
    const locationId = this.sharedService.getLocalStorageItem('selectedLocation');
    const cartId = this.sharedService.getLocalStorageItem('cartId');
    if(locationId == id && cartId){
      this.router.navigateByUrl('/booking/whoscoming');
    }else if(locationId != id && cartId){
      const message = "If you change the location, your cart will be clear.<br /> Are you sure you want to change the location?"
      this.sharedService.openConfirmationAlert(message).then((res:any)=>{
        if(res){
          this.createCart(id);
        }else{
          this.router.navigateByUrl('/booking/whoscoming');
        }
      });
    }else{
      this.createCart(id);
    }
    this.sharedService.removeLocalStorageItem('isSameService');
  }
}
