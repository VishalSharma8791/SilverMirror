import { Component } from '@angular/core';
import { GiftcardService } from '../giftcard.service';
import { Router } from '@angular/router';
import { SharedService } from 'src/app/shared-component/shared.service';
import { PDF_INTERFACE, PdfService } from '../pdf.service';
import { Subscription, firstValueFrom } from 'rxjs';
import { TrackingService } from '../tracking.service';

@Component({
  selector: 'app-thanks',
  templateUrl: './thanks.component.html',
  styleUrls: ['./thanks.component.scss']
})
export class ThanksComponent {

  cart:any;
  isCustomAmountSelected:any;
  isGiftcardPurchase:boolean = false;
  giftcardCode:any;
  cartSubscription!:Subscription;

  constructor(private giftcardService:GiftcardService, private router:Router, private trackingService:TrackingService, public sharedService:SharedService, private pdfService:PdfService){
    if(!this.cart){
      this.cartSubscription = giftcardService.clientCart$.subscribe((cart:any)=>{
        this.cart = cart;
        if(this.cart){
          const giftId = this.cart?.selectedItems[0]?.id
          if(this.cart.selectedItems.length && this.cart.selectedItems[0].item.id == 'GIFT_CARD'){
            this.isCustomAmountSelected = true;
            this.getGiftcardCode();
          }else{
            let recipient:any = localStorage.getItem('giftcardRecepient');
            if(recipient){
              recipient = JSON.parse(recipient);
              recipient.messageFromSender = recipient.messageFromSender;
              recipient.deliveryDate = recipient.deliveryDate;
              recipient.unitCost = recipient.unitCost;
              this.cart.selectedItems[0].emailFulfillment = recipient;
            }
            !this.isGiftcardPurchase ? this.giftcardPurchase() : null;
          }
        }else{
          router.navigateByUrl('/giftcards', {replaceUrl: true});
        }
      })
    }
  }

  injectGTAG(giftId:string){
    this.trackingService.setUserDetail();
    this.trackingService.purchase();

    (window as any).gtag('event', 'conversion', {
      'send_to': 'AW-1056511307/uq4qCNDxjpECEMuq5PcD',
      'value': Number(this.sharedService.formatPrice(this.cart?.summary?.total)),
      'currency': 'USD',
      'transaction_id': giftId
      });
  }

  clearCart(){
    this.giftcardService.clientCart$.next(null);
    localStorage.removeItem('giftcardRecepient');
    localStorage.removeItem('promoCode');
    this.isGiftcardPurchase = false;
    this.cartSubscription.unsubscribe();
  }

  downloadPDF(){

    const amount = !this.isCustomAmountSelected ? (this.cart?.selectedItems[0].emailFulfillment?.unitCost/100).toFixed(2) : (this.cart?.summary?.subtotal/100).toFixed(2)

    const param:PDF_INTERFACE = {
      productName: this.cart?.selectedItems[0].item.name,
      sender:this.cart?.selectedItems[0].emailFulfillment?.senderName,
      receiver:this.cart?.selectedItems[0].emailFulfillment?.recipientName,
      amount: amount,
      code:this.giftcardCode,
      message:this.cart?.selectedItems[0].emailFulfillment?.messageFromSender ? this.cart?.selectedItems[0].emailFulfillment?.messageFromSender : ''
    }

    this.pdfService.createPDF(param);
    const title = 'Silvermirror Giftcard PDF downloaded';
    const message = 'Please check your download folder.';
    this.sharedService.showNotification(title, message);
  }

  async giftcardPurchase(){
    const resClientByEmail: any = await firstValueFrom(this.giftcardService.getClientByEmail(this.cart.clientInformation.email));
    const payload = {
      "amount": this.cart?.selectedItems[0].emailFulfillment?.unitCost,
      "giftcardName": this.cart?.selectedItems[0].item.name,
      "note": "",
      "deliveryDate": this.cart?.selectedItems[0]?.emailFulfillment?.deliveryDate,
      "messageFromSender": this.cart?.selectedItems[0].emailFulfillment?.messageFromSender ? this.cart?.selectedItems[0].emailFulfillment?.messageFromSender : '',
      "recipientEmail": this.cart?.selectedItems[0]?.emailFulfillment?.recipientEmail,
      "recipientName": this.cart?.selectedItems[0].emailFulfillment?.recipientName,
      "senderName": this.cart?.selectedItems[0].emailFulfillment?.senderName,
      "clientId": resClientByEmail.data.clients.edges[0].node.id
    }

    const resProcessGiftcard: any = await firstValueFrom(this.giftcardService.processGiftcard(payload));
    if(!resProcessGiftcard.errors){
      this.giftcardCode = resProcessGiftcard.giftcard.data.giftCard.code;
      this.injectGTAG(resProcessGiftcard.giftcard.data.giftCard.id);
    }
    this.isGiftcardPurchase = true;
  }

  async getGiftcardCode(){
    const resGiftcardCode: any = await firstValueFrom(this.giftcardService.getGiftcardCode(this.cart.id));
    if(!resGiftcardCode.errors){
      this.giftcardCode = resGiftcardCode?.data?.cart?.orders[0]?.lineGroups[0]?.lines[0]?.giftCardCode;
      this.injectGTAG(this.cart.id);
    }
  }

  ngOnDestroy(){
    this.clearCart();
  }

}
