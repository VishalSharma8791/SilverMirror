import { Component } from '@angular/core';
import { GiftcardService } from '../giftcard.service';
import { firstValueFrom } from 'rxjs';
import { SharedService } from 'src/app/shared-component/shared.service';
import { AuthService } from 'src/app/auth/auth.service';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { TrackingService } from '../tracking.service';

@Component({
  selector: 'app-detail',
  templateUrl: './detail.component.html',
  styleUrls: ['./detail.component.scss']
})
export class DetailComponent {

  enableStep2:boolean = false;
  giftcardsList:any = [];
  isCustomAmountSelected:boolean = true;
  customAmount:any;
  cart:any;
  user:any;
  today:any;

  recipientType:string = "someone";
  recipientForm!:FormGroup;

  constructor(private trackingService:TrackingService, public giftcardService:GiftcardService, private sharedService:SharedService, private authService:AuthService, private formBuilder:FormBuilder, private router:Router){
    this.getToday();
    this._buildForm();
    const cartID = localStorage.getItem('giftcardCart');
    cartID ? this.getCartDetail() : null;
    this.getGiftcardsList();
    giftcardService.clientCart$.subscribe(cart=>{
      if(cart){
        this.cart = cart;
        this._patchData();
      }
    })
    this.authService.$AuthUser.subscribe((user:any)=>{
      if(user){
        this.user = user;
        this._patchAdditionalInfoForm(user);
      }
    });
  }

  _buildForm(){
    // PaymentForm
    this.recipientForm = this.formBuilder.group({
      recipientName: ['', Validators.required],
      // senderName: ['', Validators.required],
      recipientEmail: ['', Validators.compose([Validators.required, Validators.email])],
      // senderEmail: ['', Validators.compose([Validators.email])],
      message: [''],
      sendDate: [this.today, Validators.compose([Validators.required, this.sendDateValidator])],
    });
  }

  _patchAdditionalInfoForm(user:any){
    this.recipientForm.patchValue({
      // senderName:user.firstName + ' ' + user.lastName,
      // senderEmail: user.email,
      sendDate: this.today
    });
    // this.recipientForm.controls.senderEmail.disable();
    // this.recipientForm.controls.senderName.disable();
  }

  _patchData(){
    // Patch giftcard selection
    if(this.cart.selectedItems.length && this.cart.selectedItems[0].item.id == 'GIFT_CARD'){
      this.isCustomAmountSelected = true;
      this.customAmount =  this.cart?.selectedItems[0]?.price/100;
    }else if(this.cart.selectedItems.length && this.cart.selectedItems[0].item.id != 'GIFT_CARD'){
      const selectedGiftCard = this.giftcardsList.filter((giftcard:any)=>giftcard.node.name == this.cart.selectedItems[0].item.name);
      selectedGiftCard.length ? this.selectGiftCard(selectedGiftCard[0]) : null;
    }

    const recipientType = localStorage.getItem('recipientType');
    recipientType ? this.recipientType = recipientType : null;

    // Patch emailfulfilment
    if(this.isCustomAmountSelected){
      // from cart
      this._patchRecipientForm(this.cart?.selectedItems[0]?.emailFulfillment);
    }else{
      // from local storage
      let recipient:any = localStorage.getItem('giftcardRecepient');
      if(recipient){
        recipient = JSON.parse(recipient);
        recipient.messageFromSender = recipient.message;
        recipient.deliveryDate = recipient.sendDate;
        this._patchRecipientForm(recipient);
      }
    }
  }

  _patchRecipientForm(recipient:any){
    if(recipient){
      this.recipientForm.patchValue({
        recipientName: recipient.recipientName,
        // senderName: recipient.senderName,
        recipientEmail: recipient.recipientEmail,
        // senderEmail: this?.user?.email,
        message: recipient.messageFromSender,
        sendDate: new Date() > new Date(recipient.deliveryDate) ? this.today : this.getToday(recipient.deliveryDate),
      });
    }
  }

  getToday(dateValue?:string){
    let date = dateValue ? new Date(dateValue) : new Date();
    let m = Number(new Date().getMonth()) + 1;
    let y = new Date().getFullYear();
    let d = new Date().getDate();
    // let returnDate = (m < 10 ? '0'+m : m)  + '/' + (d < 10 ? '0'+d : d) + '/' + y;
    let returnDate = y + '-' + (m < 10 ? '0'+m : m)  + '-' + (d < 10 ? '0'+d : d);
    !dateValue ? this.today = returnDate : null;
    return returnDate;
  }

  sendDateValidator(control: FormControl): { [key: string]: any } | null {
    if(control.value){
      let date = new Date();
      let m = Number(new Date().getMonth()) + 1;
      let y = new Date().getFullYear();
      let d = new Date().getDate();
      let returnDate = (m < 10 ? '0'+m : m)  + '/' + (d < 10 ? '0'+d : d) + '/' + y;
      const today = returnDate;

      let controlDate =  control.value.substr(5,2) + '/' + control.value.substr(8,2) + '/' + control.value.substr(0,4);

      const valid = new Date(controlDate).setHours(0,0,0,0) >= new Date(today).setHours(0,0,0,0);

      return valid ? null : { invalidSendDate: true };
    }else{
      return { invalidSendDate: true };
    }
  }

  changeRecipient(ev:any){
    if(ev == 'myself'){
      const user = this.authService.$AuthUser.value;
      if(user){
        this.recipientForm.patchValue({
          recipientName: user.firstName + ' ' + user.lastName,
          // senderName: user.firstName + ' ' + user.lastName,
          recipientEmail: user.email,
          // senderEmail: user.email,
          sendDate: this.today
        });
      }
    }else if(ev == 'someone'){
      const user = this.authService.$AuthUser.value;
      if(user){
        this.recipientForm.reset();
        this._patchAdditionalInfoForm(user);
      }
    }else{
      this.recipientForm.reset();
    }
    localStorage.setItem('recipientType', ev);
  }

  async getGiftcardsList(){
    await this.giftcardService.getGiftcardsList().subscribe((res:any)=>{
      this.giftcardsList = res.data.products.edges;
    });
  }

  activeStep(step:number){
    this.enableStep2 = step == 1 ? false : true;
  }

  selectGiftCard(giftCard:any){
    this.isCustomAmountSelected = false;
    this.customAmount = null;
    this.giftcardsList.map((card:any)=> card.selected = false);
    giftCard.selected = true;
    // this.giftCardService.selectedGiftCard.next(giftCard);
    // this.customAmount = null;
  }

  selectCustomAmount(){
    this.isCustomAmountSelected = true;
  }

  confirmAmount(){
    if(this.isSelectedGiftcardChange()){
      this.addGiftcard();
    }else{
      this.enableStep2 = true;
    }
  }

  async addGiftcard(){
    if(this.isCustomAmountSelected){
      if(!this.customAmount || Number(this.customAmount) < 25 || Number(this.customAmount) > 1000){
        const title = 'Enter purchase amounts between $25 and $1000';
        const message = '';
        return this.sharedService.showNotification(title, message);
      }
      // Create Cart
      await this.createCart();

      // Clear Products list recipient
      localStorage.removeItem('giftcardRecepient');

      // Add GiftCard
      await this.addGiftcardInCart();

      // Cart Detail
      await this.getCartDetail();
    }else{
      // Create Cart
      await this.createCart();
      
      // Add Product
      await this.addProduct();

      // Cart Detail
      await this.getCartDetail();
    }
    this.enableStep2 = true;
  }

  async createCart(){
    const cartId = localStorage.getItem('giftcardCart');
    if(!cartId){
      const resCreateCart: any = await firstValueFrom(this.giftcardService.createCart());
      if(!resCreateCart.errors){
        localStorage.setItem('giftcardCart', resCreateCart.data.createCart.cart.id);
      }else{
        this.sharedService.showNotification("Error", resCreateCart.errors[0].message);
      }
    }
  }

  async addProduct(){
    const selectedGiftcard = this.giftcardsList.filter((giftcard:any)=> giftcard.selected);
    if(selectedGiftcard.length){
      if(this.cart && this.cart.selectedItems.length){
        const selectedItemId = this.cart.selectedItems[0].id;
        const resRemoveProduct: any = await firstValueFrom(this.giftcardService.removeProductFromCart(selectedItemId));
      }
      const itemId = selectedGiftcard[0].node.id
      const resAddProduct: any = await firstValueFrom(this.giftcardService.addProductToCart(itemId));
    }
  }

  async addGiftcardInCart(){
    if(this.cart && this.cart.selectedItems.length){
      const selectedItemId = this.cart.selectedItems[0].id;
      const trackItem = {
        name: this.cart.selectedItems[0].item.name,
        id:"GIFT_CARD",
        listPrice:this.cart.selectedItems[0].price,
        total:this.cart.summary.total
      }
      this.trackingService.removeItem(trackItem);
      const resRemoveProduct: any = await firstValueFrom(this.giftcardService.removeProductFromCart(selectedItemId));
    }
    const resAddGiftcard: any = await firstValueFrom(this.giftcardService.addGiftCard(Number(this.customAmount)));
    const trackItem = {
      name: this.cart.selectedItems[0].item.name,
      id:"GIFT_CARD",
      listPrice:this.cart.selectedItems[0].price,
      total:this.cart.summary.total
    }
    this.trackingService.addItem(trackItem);
  }

  async getCartDetail(){
    const resCartDetail: any = await firstValueFrom(this.giftcardService.cartDetail());
    if(!resCartDetail.errors){
      this.giftcardService.clientCart$.next(resCartDetail.data.cart);
    }else{
      this.sharedService.showNotification("Error", resCartDetail.errors[0].message);
    }
  }

  async addReceipient(){
    const selectedItemId = this.cart.selectedItems[0].id;
    const resCardDesign: any = await firstValueFrom(this.giftcardService.setCardDesign(selectedItemId));

    if(this.cart && this.cart?.selectedItems?.length){
      let payload = this.recipientForm.value;
      payload.senderName = "Me";
      const resEmailfulfilment: any = await firstValueFrom(this.giftcardService.updateEmailfulfilment(payload));
      if(!resEmailfulfilment.errors){
        // this.giftCardService.getCartDetail();
        const title = 'Recipient information';
        const message = 'added successfully';
        this.sharedService.showNotification(title, message);
        this.router.navigateByUrl("/giftcards/review");
      }else{
        this.sharedService.showNotification("Error", resEmailfulfilment.errors[0].message);
      }
    }else{
      // this.giftCardService.setEmailfulfilment(this.recipientForm.value).subscribe((res:any)=>{
      //   if(!res.errors){
      //     this.giftCardService.getCartDetail();
      //     this.router.navigateByUrl("/giftcard/review");
      //     // this.router.navigateByUrl("/giftcard/email-design");
      //     const title = 'Recipient information';
      //     const message = 'added successfully';
      //     this.sharedService.showNotification(title, message);
      //   }else{
      //     this.sharedService.showNotification("Error", res.errors[0].message);
      //   }
      // });
    }
  }

  async continue(){
    // Add Recepient
    if(this.isCustomAmountSelected){
      await this.addReceipient();
    }else{
      const recipient = this.recipientForm.value;
      const selectedGiftcard = this.giftcardsList.filter((giftcard:any)=>giftcard.selected);
      recipient.unitCost = selectedGiftcard[0].node.unitCost;
      localStorage.setItem("giftcardRecepient", JSON.stringify(recipient));
      this.router.navigateByUrl("/giftcards/review");
    }

    // Cart Detail
    await this.getCartDetail();
  }


  // Changes Detection
  isSelectedGiftcardChange(){
    if(this.cart && this.cart.selectedItems.length){
      if(this.isCustomAmountSelected){
        return this.cart.selectedItems[0].price != this.customAmount * 100;
      }else{
        const selectedGiftcard = this.giftcardsList.filter((giftcard:any)=>giftcard.selected);
        return this.cart.selectedItems[0].item.name != selectedGiftcard[0].node.name;
      }
    }else{
      return true;
    }
  }

}
