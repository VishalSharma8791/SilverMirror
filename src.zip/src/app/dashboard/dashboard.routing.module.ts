import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { AuthGuard } from "../guards/auth.guard";
import { AccountComponent } from "./account/account.component";
import { AppointmentComponent } from "./appointment/appointment.component";
import { DashboardComponent } from "./dashboard.component";
import { MembershipProductsComponent } from "./membership-products/membership-products.component";
import { MembershipsComponent } from "./memberships/memberships.component";
import { PurchasesComponent } from "./purchases/purchases.component";
import { RescheduleComponent } from "./reschedule/reschedule.component";
import { LoyaltyComponent } from "./loyalty/loyalty.component";

@NgModule({
  imports: [
    RouterModule.forChild([
      {
        path: "dashboard",
        component: DashboardComponent,
        children: [
          { path: "", redirectTo: "/dashboard/appointments", pathMatch: 'full' },
          {
            path: "appointments",
            component: AppointmentComponent,
            canActivate: [AuthGuard]
          },
          {
            path: "reschedule",
            component: RescheduleComponent,
            canActivate: [AuthGuard]
          },
          {
            path: "memberships",
            component: MembershipsComponent,
            canActivate: [AuthGuard]
          },
          {
            path: "membership-products",
            component: MembershipProductsComponent,
            canActivate: [AuthGuard]
          },
          {
            path: "loyalty",
            component: LoyaltyComponent,
            canActivate: [AuthGuard]
          },
          {
            path: "account",
            component: AccountComponent,
            canActivate: [AuthGuard]
          },
          {
            path: "purchases",
            component: PurchasesComponent,
            canActivate: [AuthGuard]
          },
        ],
      },
    ]),
  ],
  exports: [RouterModule],
})
export class DashboardRoutingModule {}
