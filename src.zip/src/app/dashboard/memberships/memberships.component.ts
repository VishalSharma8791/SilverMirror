import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { BehaviorSubject, forkJoin } from 'rxjs';
import { SharedService } from 'src/app/shared-component/shared.service';
import { DashboardService } from '../dashboard.service';

@Component({
  selector: 'app-memberships',
  templateUrl: './memberships.component.html',
  styleUrls: ['./memberships.component.scss']
})
export class MembershipsComponent {

  $memberships:BehaviorSubject<any> = new BehaviorSubject([]);
  $vouchers:BehaviorSubject<any> = new BehaviorSubject([]);

  constructor(private dashboardService:DashboardService, private router:Router, private sharedService:SharedService){
    this.getMembershipsList();
  }

  getMembershipsList(){
    forkJoin([this.dashboardService.myMembershipsList(), this.dashboardService.membershipVouchers()]).subscribe((res:any)=>{
      if(!res[0].errors){
        this.$memberships.next(res[0].data.myMemberships.edges);
        if(!this.$memberships.value.length){
          this.router.navigateByUrl("/dashboard/membership-products");
        }
      }else{
        const title = 'Something went wrong';
        const message = res.errors[0].message;
        this.sharedService.showNotification(title, message);
      }
      if(!res[1].errors){
        this.$vouchers.next(res[1].data.client.vouchers);
        console.log("Vouchers :: ", this.$vouchers.value);
      }else{
        const title = 'Something went wrong';
        const message = res.errors[0].message;
        this.sharedService.showNotification(title, message);
      }
    })
  }

  voucherExpiry(date:string){
    if(date){
      const currentExpiry = new Date(date);
      currentExpiry.setMonth(currentExpiry.getMonth() + 2);
      return currentExpiry;
    }else{
      return null;
    }
  }

  getCreditsTitle(membershipName:string){
    switch (membershipName) {
      case "30-Minute Facial Membership":
        return "30-Minute Facial Credit"
        break;

      case "50-Minute Facial Membership":
        return "50-Minute Facial Credit"
        break;
    
      default:
        return membershipName
        break;
    }
  }

}
