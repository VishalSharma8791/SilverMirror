import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'membershipLocation'
})
export class MembershipLocationPipe implements PipeTransform {

  transform(locations: any[]): any[] {

    if(locations.length){
      const returnedLocations = locations.map((location:any)=>{
        if(location.node?.address){
          location.node.name = location.node?.address?.state + ' - ' + location.node.name;
        }
        return location;
      })
      returnedLocations.sort((a,b)=> {
        if (a.node.name < b.node.name) {
          return -1;
        }
        if (a.node.name > b.node.name) {
          return 1;
        }
        return 0;
      });
      returnedLocations.unshift(returnedLocations[returnedLocations.length - 1]);
      returnedLocations.splice((returnedLocations.length - 1) , 1);
      return returnedLocations;
    }else{
      return locations
    }
  
    // return locations;
  }
}
