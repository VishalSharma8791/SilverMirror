import { Component } from '@angular/core';
import { MembershipService } from '../membership.service';
import { SharedService } from 'src/app/shared-component/shared.service';
import { firstValueFrom } from 'rxjs';

@Component({
  selector: 'app-completed',
  templateUrl: './completed.component.html',
  styleUrls: ['./completed.component.scss']
})
export class CompletedComponent {

  cart:any;

  // today = new Date(new Date().setDate(Number(localStorage.getItem('billDate'))));
  // nextBilling = this.addMonths(this.today, 1).toLocaleDateString('en-us', { year: "numeric", month: "short", day: "numeric" }).replace(",", "")

  constructor(private membershipService:MembershipService, private sharedService:SharedService){
    membershipService.completeCart$.subscribe((cart:any)=>{
      if(cart){
        this.cart = cart;
        this.saveMembershipDetail();
      }
    })
  }

  async saveMembershipDetail(){
    const billDate:any = localStorage.getItem('billDate');
    const payload = {
      "date": new Date().toISOString(),
      "name": this.cart.clientInformation.firstName + ' ' + this.cart.clientInformation.lastName,
      "email": this.cart.clientInformation.email,
      "plan": this.cart.selectedItems[0].item.name,
      "start_date": billDate,
      "location": this.cart.location.name
    }
    const saveMembershipRes:any = await firstValueFrom(this.membershipService.saveMembershipClientDetail(payload));
    if (saveMembershipRes.errors) {
      return this.sharedService.showNotification("Add Payment Method Error", saveMembershipRes.errors[0].message);
    }
    localStorage.removeItem('billDate');
  }

  // addMonths(date: Date, months: number) {
  //   date.setMonth(date.getMonth() + months);
  
  //   return date;
  // }

}
