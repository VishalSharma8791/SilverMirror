import { Component } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { FormBuilder, FormControl, FormGroup, Validators } from "@angular/forms";
import { AuthService } from "../../auth/auth.service";
import { SharedService } from "src/app/shared-component/shared.service";
import { BookingService } from "src/app/booking/booking.service";
import { firstValueFrom } from "rxjs";
import { MembershipService } from "../membership.service";
// import { TrackingService } from "../tracking.service";

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.scss']
})
export class PaymentComponent {
  activeTab = 0;
  paymentForm!:FormGroup;
  couponForm!:FormGroup;
  availablePaymentMethods:any = [];
  // loading = false;
  // submitted = false;
  authUser: {
    firstName?: string;
    lastName?: string;
    email?: string;
    mobilePhone?: string;
  } = {};

  cart: any;
  // summary = {
  //   discountAmount: 0,
  //   gratuityAmount: 0,
  //   paymentMethodRequired: true,
  //   roundingAmount: 0,
  //   subtotal: 0,
  //   taxAmount: 0, 
  //   total: 0
  // };

  // today = new Date(new Date().setDate(this.membershipPurchaseService.$membershipData.value.membershipSelection.billDate));
  // nextBilling = this.addMonths(this.today, 1).toLocaleDateString('en-us', { year: "numeric", month: "short", day: "numeric" }).replace(",", "")

  constructor(
    // public membershipPurchaseService: MembershipPurchaseService,
    public membershipService:MembershipService,
    private formBuilder: FormBuilder,
    public authService: AuthService,
    private sharedService: SharedService,
    public bookingService: BookingService,
    private route: ActivatedRoute,
    private router: Router,
    // private trackingService:TrackingService
  ) {
    this.authService.$AuthUser.subscribe((user: any) => {
      this.authUser = user;
    });
    membershipService.clientCart$.subscribe((cart:any)=>{
      if(cart){
        this.cart = cart;
        this.availablePaymentMethods = cart.availablePaymentMethods;
        setTimeout(() => {
          this._patchCouponForm(cart.offers);
        }, 10);
        console.log("Cart detail :: ", cart);
      }else{
        this.membershipService.getCartDetail();
      }
    })
  }

  async ngOnInit() {
    // const membershipData = this.membershipPurchaseService.$membershipData;
    // if (membershipData.value && membershipData.value.membershipSelection.location === "") {
    //   return this.navigateToOptions(); // Invalid state, return to start
    // }
    this._buildForm();
    
    // const membershipSelection = this.membershipPurchaseService.$membershipData.value.membershipSelection;

    // let cart: any = this.getCart();
    // if (!cart) {
    //   cart = await this.createCart();
    //   if (!cart) {
    //     this.sharedService.showNotification('Cart', 'Error creating cart');
    //     return null;
    //   }
    //   const item = {
    //     id: cart.data.createCart.cart.id,
    //     // itemId: membershipSelection.selectedMembership.id,
    //   };
    //   const resAddProduct: any = await firstValueFrom(this.bookingService.addProductToCart(item));
    //   cart = await this.getCart();
    //   if (resAddProduct.errors) {
    //     return this.sharedService.showNotification("Error", "Error adding items to cart");
    //   }
    //   // cart ? this.trackingService.initiateCheckout(cart) : null;
    // }

    // const detail: any = await firstValueFrom(this.bookingService.getCartDetail(cart.data.createCart.cart.id));
    // this.summary = detail.data.cart.summary;
    // this.membershipPurchaseService.$membershipData.next(Object.assign(this.membershipPurchaseService.$membershipData.value, {
    //   summary: { ...detail.data.cart.summary }
    // }));

    // this.cart = cart;
  }

  _buildForm(){
    // PaymentForm
    this.paymentForm = this.formBuilder.group({
      name: ['', Validators.required],
      number: ['', Validators.compose([Validators.required, Validators.maxLength(19), Validators.minLength(9)])],
      cvv: ['', Validators.compose([Validators.required, Validators.maxLength(4), Validators.minLength(3), this.cvvValidator])],
      expiry: ['', Validators.compose([Validators.required, Validators.maxLength(7), Validators.minLength(7), this.expiryValidator])],
      postal_code: ['', Validators.compose([Validators.required, Validators.maxLength(5), Validators.minLength(5)])],
    });

    this.couponForm = this.formBuilder.group({
      promoCode: ['', Validators.required]
    });
  }

  cvvValidator(control: FormControl): { [key: string]: any } | null {
    const valid = /^\d{3,4}$/.test(control.value);
    return valid ? null : { invalidCVV: true };
  }

  expiryValidator(control: FormControl): { [key: string]: any } | null {
    if(control.value){
      const splitVal = control.value.split('/')
      const month = Number(splitVal[0]);
      const year = Number(splitVal[1]);
      const currentYear = new Date().getFullYear();
      const currentMonth = new Date().getMonth() + 1;
      const valid = year >= currentYear && splitVal[0].length && ((currentYear == year && month >= currentMonth) || (year > currentYear && month <= 12));
      return valid ? null : { invalidExpiry: true };
    }else{
      return { invalidExpiry: true };
    }
  }

  maskExpiryDate(expiryDate: string): string {
    // Extract the month and year from the expiry date string
    const [month, year] = expiryDate.split('/');
  
    // Replace the year with asterisks
    const maskedYear = year;
  
    // Concatenate the masked month and year with a forward slash
    const maskedExpiryDate = `${month}/${maskedYear}`;
  
    return maskedExpiryDate;
  }

  onExpiryDateInput(): void {
    // Get the raw input value from the input field
    const rawValue = this.paymentForm.value.expiry.replace(/\D/g, '');

    // Extract the month and year components from the raw input value
    const month = rawValue.substr(0, 2);
    const year = rawValue.substr(2, 4);

    // Mask the expiry date
    const maskedExpiryDate = this.maskExpiryDate(`${month}/${year}`);

    // Update the input field value with the masked expiry date
    this.paymentForm.patchValue({
      expiry:maskedExpiryDate
    });
  }

  _patchCouponForm(offers:any){
    if(offers && offers.length){
      let code = offers[0].code;
      this.couponForm.patchValue({
        promoCode: code
      });
      this.couponForm.disable();
    } else{
      this.couponForm.patchValue({
        promoCode: ''
      });
      this.couponForm.enable();
    }
  }

  autoApplyPromoCode(){
    const coupon = this.sharedService.getLocalStorageItem('coupon');
    if(coupon){
      this.bookingService.addCartOffer(coupon, this.cart.id).subscribe((res:any)=>{
        if(!res.errors && res?.data?.addCartOffer?.offer?.applied){
          const title = 'Promo code';
          const message = 'applied successfully';
          this.sharedService.showNotification(title, message);
          this.membershipService.getCartDetail();
          this.sharedService.removeLocalStorageItem('coupon');
        }else{
          const title = 'Invalid promo code';
          const message = 'Please enter valid promo code';
          this.sharedService.showNotification(title, message);
          !res?.data?.addCartOffer?.offer?.applied ? this.bookingService.removeCartOffer(res?.data?.addCartOffer?.offer?.id, this.cart.id).subscribe() : null;
        }
      })
    }
  }

  applyPromoCode(){
    const code = this.couponForm.value.promoCode;
    if(this.couponForm.valid && code!=''){
      this.bookingService.addCartOffer(code, this.cart.id).subscribe((res:any)=>{
        if(!res.errors && res?.data?.addCartOffer?.offer?.applied){
          const title = 'Promo code';
          const message = 'applied successfully';
          this.sharedService.showNotification(title, message);
          this.membershipService.getCartDetail();
        }else{
          const title = 'Invalid promo code';
          const message = 'Please enter valid promo code';
          this.sharedService.showNotification(title, message);
          !res?.data?.addCartOffer?.offer?.applied ? this.bookingService.removeCartOffer(res?.data?.addCartOffer?.offer?.id, this.cart.id).subscribe() : null;
        }
      })
    }else{
      this.couponForm.markAllAsTouched();
      const title = 'Incorrect promo code';
      const message = 'Please fill the correct promo code';
      this.sharedService.showNotification(title, message);
    }
  }

  removePromoCode(){
    let offerId = this.cart.offers[0].id;
    if(offerId){
      this.bookingService.removeCartOffer(offerId, this.cart.id).subscribe((res:any)=>{
        if(!res.errors){
          const title = 'Promo code';
          const message = 'removed successfully';
          this.sharedService.showNotification(title, message);
          this.membershipService.getCartDetail();
        }
      })
    }
  }

  // addMonths(date: Date, months: number) {
  //   date.setMonth(date.getMonth() + months);
  
  //   return date;
  // }

  // getCart() {
  //   const localCart = localStorage.getItem("membershipCart");
  //   const expiration = localStorage.getItem("membershipCartExpiration");
  //   if (localCart && expiration && Date.parse(expiration) < Date.now() + 24 * 60 * 60 * 1000) {  // set the expiration to a day
  //     return JSON.parse(localCart);
  //   }

  //   return null;
  // }

  // async createCart() {
    // const membershipSelection = this.membershipPurchaseService.$membershipData.value.membershipSelection;

    // const cart: any = await firstValueFrom(this.bookingService.createCart(membershipSelection.location));

    // if (cart.errors) {
    //   return this.sharedService.showNotification("Error", "Error creating cart");
    // }
    // localStorage.setItem("membershipCart", JSON.stringify(cart));
    // localStorage.setItem("membershipCartExpiration", Date());

    // return cart;
  // }

  // async submitDiscountCode(e: any) {
  //   const discountCode = this.form.value.discountCode ? this.form.value.discountCode : this.form.value.discountCodeMobile;

  //   this.bookingService.addCartOffer(discountCode, this.cart.data.createCart.cart.id).subscribe((res: any) => {
  //     if (!res.errors && res?.data?.addCartOffer?.offer?.applied) {
  //       this.sharedService.showNotification('Promo code', 'Applied successfully');
  //       this.form.controls.discountCode.setErrors(null)
  //       this.summary = res?.data?.addCartOffer.cart.summary;
  //       // this.membershipPurchaseService.$membershipData.next(Object.assign(this.membershipPurchaseService.$membershipData.value, {
  //       //   summary: { ...res?.data?.addCartOffer.cart.summary }
  //       // }));
  //     } else {
  //       this.sharedService.showNotification('Invalid promo code', 'Please enter valid promo code.');
  //       this.form.controls.discountCode.setErrors({invalidPromo:true}) 
  //       console.log(this.form.controls.discountCode);
  //       !res?.data?.addCartOffer?.offer?.applied ? this.bookingService.removeCartOffer(res?.data?.addCartOffer?.offer?.id).subscribe() : null;
  //     }
  //   });

  //   return e.preventDefault();
  // }

  // async submitPaymentForm() {
  //   this.submitted = true;

  //   let formValue = this.form.value;

  //   if (this.form.invalid) {
  //     this.sharedService.showNotification("Invalid Data Provided", "Please fill the correct information in the card information form.");
  //     return;
  //   }

  //   const exp = formValue.exp.split("/");
  //   const currentYear = parseInt(new Date().getFullYear().toString().substring(2, 4));
  //   const currentMonth = new Date().getMonth() + 1;
  //   if (exp.length < 2 || exp[0].length != 2 || exp[1].length != 2) {
  //     return this.sharedService.showNotification("Error", "Expiration needs to be in the format of mm/yy");
  //   }
  //   if (parseInt(exp[1]) < currentYear || (parseInt(exp[1]) === currentYear && parseInt(exp[0]) < currentMonth)) {
  //     return this.sharedService.showNotification("Error", "Expiration needs to be a date in the future");
  //   }

  //   // const membershipSelection = this.membershipPurchaseService.$membershipData.value.membershipSelection;
  //   // const agreementData = this.membershipPurchaseService.$membershipData.value.agreementData;

  //   const clientMessage = formValue.clientMessage;

  //   // await this.membershipPurchaseService.tokenizeCard({
  //   //   name: formValue.name,
  //   //   number: formValue.number,
  //   //   cvv: formValue.cvv,
  //   //   postal_code: formValue.zip,
  //   //   expiry: formValue.exp,
  //   // }).subscribe({
  //   //   next: async (resTokenization: any) => {
  //   //     const cartId = this.cart.data.createCart.cart.id;
        
  //   //     try {
  //   //       await firstValueFrom(this.bookingService.addCartPaymentMethod(resTokenization.token, cartId));
  //   //     } catch (err) {
  //   //       this.sharedService.showNotification("Error", "Error adding payment method");
  //   //       return;
  //   //     }
  //   //     const client = {
  //   //       email: membershipSelection.email,
  //   //       firstName: membershipSelection.firstName,
  //   //       lastName: membershipSelection.lastName,
  //   //       phoneNumber: membershipSelection.phone,
  //   //       note: clientMessage,
  //   //     };
  //   //     try {
  //   //       await firstValueFrom(this.bookingService.updateClientCartInfo(client, cartId));
  //   //     } catch (err) { 
  //   //       this.sharedService.showNotification("Error", "Error adding client information to cart");
  //   //       return;
  //   //     }
  //   //     try {
  //   //       const resCheckout: any = await firstValueFrom(this.bookingService.checkoutCart(cartId));
  //   //       localStorage.removeItem("membershipCart");

  //   //       const summary = resCheckout.data.checkoutCart.cart.summary;
  //   //       this.membershipPurchaseService.$membershipData.next(Object.assign(this.membershipPurchaseService.$membershipData.value, {
  //   //         summary: { ...summary },
  //   //         cart: { ...resCheckout.data.checkoutCart.cart }
  //   //       }));
  //   //     } catch (err) {
  //   //       this.sharedService.showNotification("Error", "Error during checkout");
  //   //       return;
  //   //     }

  //   //     const agreementPayload = {
  //   //       firstName: membershipSelection.firstName,
  //   //       lastName: membershipSelection.lastName,
  //   //       phoneNumber: membershipSelection.phone,
  //   //       email: membershipSelection.email,
  //   //       membershipChargeDate: membershipSelection.billDate,
  //   //       facialTypeChoice: membershipSelection.selectedMembership.name,
  //   //       initials: agreementData.waiver1.toUpperCase(),
  //   //     }

  //       // try {
  //       //   await firstValueFrom(this.membershipPurchaseService.generateAgreement(agreementPayload));
  //       // } catch (err) {
  //       //   this.sharedService.showNotification("Error", "Error generating agreement, please get in touch with us.");
  //       // }
  //       // this.navigateToCompleted();
  //     // },
  //     // error: (err: any) => {
  //     //   this.sharedService.showNotification("Error", "There is an error with your payment information");
  //     // }
  //   // });
  // }

  navigateToOptions() {
    this.router.navigateByUrl("/membership/selection");
  }
  navigateToAgreement() {
    this.router.navigateByUrl("/membership/agreement");
  }
  navigateToCompleted() {
    this.router.navigateByUrl("/membership/completed");
  }

  // numKeyDown(event: any) {
  //   const patternNum = /[0-9]/;
  //   let inputChar = event.key.trim();

  //   if (inputChar.length <= 1 && !patternNum.test(inputChar)) {
  //     event.preventDefault();
  //   }
  // }

  // expKeyDown(event: any) {
  //   const patternNum = /[0-9]/;
  //   const patternSlash = /[\/]/;
  //   const patternToTest = this.form.value.exp.length === 2 ? patternSlash : patternNum;
  //   let inputChar = event.key.trim();

  //   if (inputChar.length <= 1 && !patternToTest.test(inputChar)) {
  //     event.preventDefault();
  //   }
  // }

  // getFormValidationErrors() {
  //   let errors: string[] = [];
  //   Object.keys(this.form.controls).forEach((key) => {
  //     const controlErrors = this?.form?.get(key)?.errors;
  //     if (controlErrors != null) {
  //       Object.keys(controlErrors).forEach((keyError) => {
  //         errors.push(
  //           "Key control: " + key + ", keyError: " + keyError + ", err value: " + controlErrors[keyError]
  //         );
  //       });
  //     }
  //   });
  //   return errors;
  // }

  selectPaymentMethod(card:any){
    this.membershipService.selectPaymentMethod(card.id).subscribe((res:any)=>{
      if(!res.errors){
        card.active = true;
        this.membershipService.getCartDetail();
      }
    })
  }

  async submitPaymentForm(){
    if(this.cart?.selectedItems[0]?.selectedPaymentMethod?.id){
      const res:any = await firstValueFrom(this.bookingService.checkoutCart(this.cart.id));
      if (res.errors) {
        return this.sharedService.showNotification("Checkout Error", res.errors[0].message);
      }
      this.paymentForm.reset();
        
      // Clear membership cart from local storage
      localStorage.removeItem('membershipCart');
      
      // Clear membership agreement from local storage
      localStorage.removeItem('membershipAgreement');
      // localStorage.removeItem('billDate');

      this.membershipService.completeCart$.next(this.cart);
      
      // navigate to completed page
      this.navigateToCompleted();
    }else{
      if(this.paymentForm.valid){
        const tokenizeRes:any = await firstValueFrom(this.bookingService.tokenizeCard(this.paymentForm.value));
        if (tokenizeRes.errors) {
          let message = 'Please add correct card';
          if(tokenizeRes?.error?.errors?.number_last4?.length){
            message = 'Please check your card number'
            this.paymentForm.controls['number'].setErrors({invalidCard: true});
          }
          const title = 'Incorrect payment information';
          return this.sharedService.showNotification(title, message);
        }

        const addCardPaymentRes:any = await firstValueFrom(this.bookingService.addCartPaymentMethod(tokenizeRes.token, this.cart.id));
        if (addCardPaymentRes.errors) {
          return this.sharedService.showNotification("Add Payment Method Error", addCardPaymentRes.errors[0].message);
        }

        const res:any = await firstValueFrom(this.bookingService.checkoutCart(this.cart.id));
        if (res.errors) {
          return this.sharedService.showNotification("Checkout Error", res.errors[0].message);
        }

        let agreement:any = localStorage.getItem('membershipAgreement');
        if(agreement){
          agreement = JSON.parse(agreement);
          const billDate:any = Number(localStorage.getItem('billDate'));
          const agreementPayload = {
            firstName: this.cart.clientInformation.firstName,
            lastName: this.cart.clientInformation.lastName,
            phoneNumber: this.cart.clientInformation.phoneNumber ? this.cart.clientInformation.phoneNumber : '',
            email: this.cart.clientInformation.email,
            membershipChargeDate: billDate,
            facialTypeChoice: this.cart.selectedItems[0].item.name,
            initials: agreement.waiver1.toUpperCase(),
          }



          const agreementRes:any = await firstValueFrom(this.membershipService.generateAgreement(agreementPayload));
          if (agreementRes.errors) {
            return this.sharedService.showNotification("Save Agreement Error", res.errors[0].message);
          }
        }

        // Clear payment form
        this.paymentForm.reset();
        
        // Clear membership cart from local storage
        localStorage.removeItem('membershipCart');
        
        // Clear membership agreement from local storage
        localStorage.removeItem('membershipAgreement');
        // localStorage.removeItem('billDate');

        this.membershipService.completeCart$.next(this.cart);
        
        // navigate to completed page
        this.navigateToCompleted();
          
      }else{
        this.paymentForm.markAllAsTouched();
        const title = 'Incorrect payment information';
        const message = 'Please add correct card';
        this.sharedService.showNotification(title, message);
      }
    }
  }
}
