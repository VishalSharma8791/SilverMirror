import { commonEnv } from "./environment.common";

const env: Partial<typeof commonEnv> = {
    production: false,
    environmentName: "production",
    apiBaseURL: "https://blvdpdstg.silvermirror.com", // BLVD Production (V3)
    paymentApiBaseURL: "https://pci.boulevard.app",
    giftcard_location_id: "urn:blvd:Location:0d3803fd-52aa-4d65-9828-78613f9f73f0",
    nutrition_location_id:"urn:blvd:Location:01b80da8-0b5e-440a-b18b-03afbf5686bd", // Coral Gables
    nutrition_tag_id:"493632c5-2013-4e15-aac2-dfab0fdbba18" // Nutrition

};

// Export all settings of common replaced by dev options
export const environment = Object.assign(commonEnv, env);
