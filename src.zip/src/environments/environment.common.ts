export const commonEnv = {
    production: false,
    environmentName: "development",
    apiBaseURL: "https://stgblvd.silvermirror.com",  // BLVD Staging 
    // apiBaseURL: "http://localhost:4200",
    paymentApiBaseURL: "https://vault-sandbox.joinblvd.com",
    giftcard_location_id: "urn:blvd:Location:0d3803fd-52aa-4d65-9828-78613f9f73f0", // Santa Monica
    nutrition_location_id:"urn:blvd:Location:0d3803fd-52aa-4d65-9828-78613f9f73f0", // Santa Monica
    nutrition_tag_id:"493632c5-2013-4e15-aac2-dfab0fdbba18" // Nutrition

};
